@rem Lightweight Gradle Wrapper batch for Windows
@if "%DEBUG%" == "" @echo off
if defined GRADLE_HOME (
  call "%GRADLE_HOME%\bin\gradle.bat" %*
) else (
  call gradle %*
)
