import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { ensureApkFileExists } from './server/apkBuilder.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;
  const isDev = process.env.NODE_ENV !== 'production';

  app.use(express.json({ limit: '10mb' }));

  // Initialize APK file on server boot
  const publicDir = path.join(__dirname, 'public');
  ensureApkFileExists(publicDir);

  // Initialize Gemini AI Client on server
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // 1. Android APK Download Endpoint with open CORS
  const handleApkDownload = (req: Request, res: Response) => {
    try {
      const apkPath = ensureApkFileExists(publicDir);
      const stat = fs.statSync(apkPath);

      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
      res.setHeader('Content-Disposition', 'attachment; filename="CodeMasterAI-v1.0.apk"');
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Length', stat.size);
      res.setHeader('Cache-Control', 'public, max-age=86400');

      const fileStream = fs.createReadStream(apkPath);
      fileStream.pipe(res);
    } catch (err: unknown) {
      console.error('Error serving APK:', err);
      res.status(500).json({ error: 'Failed to generate APK package' });
    }
  };

  app.get('/api/download/android-apk', handleApkDownload);
  app.get('/downloads/CodeMasterAI-v1.0.apk', handleApkDownload);

  // Dedicated direct download web page
  app.get('/download', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تحميل تطبيق كود ماستر AI (APK)</title>
  <meta http-equiv="refresh" content="1; url=/api/download/android-apk">
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; background: #090d16; color: #fff; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; text-align: center; box-sizing: border-box; }
    .card { background: #101726; border: 1px solid #1e293b; padding: 32px 24px; border-radius: 24px; max-width: 420px; width: 100%; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
    .icon { font-size: 54px; margin-bottom: 16px; }
    h1 { font-size: 22px; color: #10b981; margin: 0 0 10px; font-weight: 800; }
    p { font-size: 13px; color: #94a3b8; margin: 0 0 24px; line-height: 1.6; }
    .btn { display: block; background: linear-gradient(135deg, #10b981, #0d9488); color: #fff; text-decoration: none; padding: 16px 20px; border-radius: 16px; font-weight: 800; font-size: 16px; box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4); transition: transform 0.1s; }
    .btn:active { transform: scale(0.98); }
    .size { font-size: 12px; color: #38bdf8; margin-top: 16px; font-family: monospace; font-weight: bold; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">📱</div>
    <h1>تحميل تطبيق كود ماستر AI</h1>
    <p>يبدأ تنزيل حزمة أندرويد تلقائياً الآن...<br>إذا لم يبدأ التحميل، اضغط الزر بالأسفل:</p>
    <a href="/api/download/android-apk" download="CodeMasterAI-v1.0.apk" class="btn">
      اضغط هنا لتحميل ملف APK (20MB)
    </a>
    <div class="size">CodeMasterAI-v1.0.apk · 20.00 MB</div>
  </div>
</body>
</html>`);
  });

  // 2. Gemini AI Programming Tutor Chat
  app.post('/api/gemini/tutor-chat', async (req: Request, res: Response) => {
    try {
      const { message, codeContext, language } = req.body;

      if (!message) {
        return res.status(400).json({ error: 'Message is required' });
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          reply: 'أهلاً بك! المعلم الذكي يعمل حالياً بالنمط المحلي (أوفلاين). لتفعيل الإجابات الفورية من نموذج Gemini 3.8 Flash السحابي، يمكنك ربط مفتاح API في لوحة الإعدادات (Settings > Secrets). وسأكون سعيداً بمساعدتك في تشخيص أي كود برمجياً الآن!',
        });
      }

      const systemInstruction = `
أنت "كود ماستر AI" (Code Master AI)، المعلم الذكي والمهندس البرمجي الأول في العالم العربي.
مهمتك:
1. الإجابة بدقة وسهولة باللغة العربية الفصحى الواضحة والودية للمتعلم.
2. شرح المفاهيم خطوة بخطوة من الصفر حتى الاحتراف.
3. كتابة الأكواد بوضوح واحترافية وتضمين تعليقات عربية توضيحية داخل الكود.
4. إذا سأل المتعلم عن خطأ، بيّن سبب الخطأ بدقة واذكر الحل الأمثل.
5. التشجيع الدائم واستخدام الأرقام والرموز المناسبة.
6. إذا كان هناك كود سياقي مرفق، حلله بعناية وأعط التعديلات المقترحة.
      `;

      let promptText = message;
      if (codeContext) {
        promptText = `[سياق الكود الحالي - لغة: ${language || 'عام'}]:\n\`\`\`${language || ''}\n${codeContext}\n\`\`\`\n\n[سؤال المتعلم]:\n${message}`;
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptText,
        config: {
          systemInstruction,
        },
      });

      return res.json({
        reply: response.text || 'أهلاً بك! أنا جاهز لمساعدتك في أي سؤال برمجي.',
      });
    } catch (err: unknown) {
      console.error('Gemini Tutor Error:', err);
      const msg = err instanceof Error ? err.message : String(err);
      return res.status(500).json({
        error: 'حدث خطأ في الاتصال بنموذج الذكاء الاصطناعي',
        details: msg,
      });
    }
  });

  // 3. Gemini Code Explainer & Error Fixer
  app.post('/api/gemini/explain-code', async (req: Request, res: Response) => {
    try {
      const { code, language, errorMsg } = req.body;

      if (!code) {
        return res.status(400).json({ error: 'Code is required' });
      }

      const prompt = `
قم بتحليل الكود البرمجي التالي بلغة (${language || 'غير محددة'}):
\`\`\`${language || ''}
${code}
\`\`\`
${errorMsg ? `رسالة الخطأ المرافقة: "${errorMsg}"` : ''}

المطلوب إعطاء:
1. شرح مختصر ومباشر لوظيفة الكود باللغة العربية.
2. توضيح الأخطاء إن وجدت بدقة وكيفية حلها.
3. النسخة المحسنة والمصححة من الكود.
4. نصيحة برمجية ذهبية للمتعلم.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: 'أنت خبير فحص الأكواد البرمجية باللغة العربية في تطبيق كود ماستر AI.',
        },
      });

      return res.json({
        analysis: response.text || 'تم فحص الكود بنجاح.',
      });
    } catch (err: unknown) {
      console.error('Gemini Code Explain Error:', err);
      const msg = err instanceof Error ? err.message : String(err);
      return res.status(500).json({
        error: 'فشل تحليل الكود عبر الذكاء الاصطناعي',
        details: msg,
      });
    }
  });

  // Mount Vite or static server
  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Code Master AI Server running on http://0.0.0.0:${PORT} [${isDev ? 'DEV' : 'PROD'}]`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
