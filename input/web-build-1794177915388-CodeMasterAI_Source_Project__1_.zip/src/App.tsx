import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { BottomNav, TabType } from './components/BottomNav.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { AcademyView } from './components/AcademyView.tsx';
import { CodeEditorView } from './components/CodeEditorView.tsx';
import { AITutorView } from './components/AITutorView.tsx';
import { ProjectsView } from './components/ProjectsView.tsx';
import { DownloadApkModal } from './components/DownloadApkModal.tsx';
import { getUserProfile, UserProfile, saveUserProfile } from './utils/storage.ts';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('dashboard');
  const [profile, setProfile] = useState<UserProfile>(getUserProfile());
  const [selectedCourseId, setSelectedCourseId] = useState<string>('python-core');
  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Editor states
  const [editorCode, setEditorCode] = useState<string | undefined>();
  const [editorLanguage, setEditorLanguage] = useState<string | undefined>();

  // AI Tutor states
  const [tutorPrompt, setTutorPrompt] = useState<string | undefined>();
  const [tutorCodeContext, setTutorCodeContext] = useState<string | undefined>();
  const [tutorLanguage, setTutorLanguage] = useState<string | undefined>();

  // Listen to connectivity changes
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleOpenInEditor = (code: string, language: string) => {
    setEditorCode(code);
    setEditorLanguage(language);
    setCurrentTab('editor');
  };

  const handleAskAiAboutError = (code: string, errorMsg: string, language: string) => {
    setTutorPrompt(`ظهر لي الخطأ التالي في كودي:\n${errorMsg}\n\nكيف أحل هذا الخطأ؟`);
    setTutorCodeContext(code);
    setTutorLanguage(language);
    setCurrentTab('tutor');
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30">
      {/* Top Mobile/Desktop Header */}
      <Header
        profile={profile}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        isOnline={isOnline}
      />

      {/* Main Screen Content */}
      <main className="flex-1">
        {currentTab === 'dashboard' && (
          <DashboardView
            profile={profile}
            onNavigateTab={setCurrentTab}
            onSelectCourse={setSelectedCourseId}
            onOpenProject={(projId) => {
              setCurrentTab('projects');
            }}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}

        {currentTab === 'academy' && (
          <AcademyView
            profile={profile}
            selectedCourseId={selectedCourseId}
            onSelectCourse={setSelectedCourseId}
            onOpenInEditor={handleOpenInEditor}
            onProfileUpdated={(updated) => {
              setProfile({ ...updated });
              saveUserProfile(updated);
            }}
          />
        )}

        {currentTab === 'editor' && (
          <CodeEditorView
            initialCode={editorCode}
            initialLanguage={editorLanguage}
            onAskAiAboutError={handleAskAiAboutError}
          />
        )}

        {currentTab === 'tutor' && (
          <AITutorView
            initialPrompt={tutorPrompt}
            codeContext={tutorCodeContext}
            languageContext={tutorLanguage}
            isOnline={isOnline}
            onOpenInEditor={handleOpenInEditor}
          />
        )}

        {currentTab === 'projects' && (
          <ProjectsView
            profile={profile}
            onOpenProjectInEditor={handleOpenInEditor}
          />
        )}
      </main>

      {/* Bottom Thumb Navigation Bar */}
      <BottomNav currentTab={currentTab} onSelectTab={setCurrentTab} />

      {/* Official Android APK Download Modal */}
      <DownloadApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
}
