export interface ExecutionResult {
  output: string;
  isError: boolean;
  errorLine?: number;
  rawError?: string;
  renderHtml?: string;
}

export function runHtmlCode(code: string): ExecutionResult {
  try {
    // Inject console capture into html code
    const consoleCaptureScript = `
      <script>
        (function() {
          const oldLog = console.log;
          const oldError = console.error;
          window.__logs = [];
          console.log = function(...args) {
            window.__logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
            oldLog.apply(console, args);
          };
          console.error = function(...args) {
            window.__logs.push('❌ خطأ: ' + args.join(' '));
            oldError.apply(console, args);
          };
          window.onerror = function(msg, url, line) {
            window.__logs.push('❌ خطأ تنفيذي سطر ' + line + ': ' + msg);
          };
        })();
      </script>
    `;

    const fullHtml = code.includes('<head>')
      ? code.replace('<head>', '<head>' + consoleCaptureScript)
      : consoleCaptureScript + code;

    return {
      output: 'تم تجهيز المعاينة الحية بنجاح 🚀',
      isError: false,
      renderHtml: fullHtml
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      output: `❌ خطأ في تشغيل كود HTML: ${errorMsg}`,
      isError: true,
      rawError: errorMsg
    };
  }
}

export function runPythonCode(code: string): ExecutionResult {
  const logs: string[] = [];
  
  // Syntax checks before running
  const lines = code.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;

    // Check missing colon
    if (/^(if|elif|else|for|while|def|class)\b/.test(trimmed) && !trimmed.endsWith(':')) {
      return {
        output: `خطأ نحوي في السطر ${i + 1}:\n  ${trimmed}\nSyntaxError: expected ':' (نسيت كتابة النقطتين : في نهاية السطر)`,
        isError: true,
        errorLine: i + 1,
        rawError: "SyntaxError: expected ':'"
      };
    }

    // Check unclosed quote
    const singleQuotes = (trimmed.match(/'/g) || []).length;
    const doubleQuotes = (trimmed.match(/"/g) || []).length;
    if (singleQuotes % 2 !== 0 && doubleQuotes % 2 === 0) {
      return {
        output: `خطأ نحوي في السطر ${i + 1}:\n  ${trimmed}\nSyntaxError: EOL while scanning string literal (علامة تنصيص مفردة ' غير مغلقة)`,
        isError: true,
        errorLine: i + 1,
        rawError: "SyntaxError: EOL while scanning string literal"
      };
    }
  }

  try {
    // Transform python basic commands into executable JS with custom print
    // Support print(), loops, range(), arithmetic, f-strings, variables
    const simulatedEnv = {
      print: (...args: unknown[]) => {
        logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));
      },
      range: (start: number, stop?: number, step = 1) => {
        if (stop === undefined) {
          stop = start;
          start = 0;
        }
        const arr: number[] = [];
        for (let i = start; i < stop; i += step) {
          arr.push(i);
        }
        return arr;
      },
      len: (obj: unknown) => {
        if (Array.isArray(obj) || typeof obj === 'string') return obj.length;
        if (typeof obj === 'object' && obj !== null) return Object.keys(obj).length;
        return 0;
      },
      sum: (arr: number[]) => arr.reduce((a, b) => a + b, 0),
      max: (arr: unknown[], keyFn?: (item: unknown) => number) => {
        if (!arr.length) return null;
        if (!keyFn) return Math.max(...(arr as number[]));
        return arr.reduce((prev, curr) => (keyFn(curr) > keyFn(prev) ? curr : prev));
      },
      min: (arr: unknown[], keyFn?: (item: unknown) => number) => {
        if (!arr.length) return null;
        if (!keyFn) return Math.min(...(arr as number[]));
        return arr.reduce((prev, curr) => (keyFn(curr) < keyFn(prev) ? curr : prev));
      }
    };

    // Python-to-JS transpiler light
    let jsCode = '';
    for (let i = 0; i < lines.length; i++) {
      let l = lines[i];
      // Comments
      if (l.trim().startsWith('#')) {
        jsCode += `// ${l.trim().slice(1)}\n`;
        continue;
      }
      
      // Convert f-strings: f"Hello {x}" -> `Hello ${x}`
      l = l.replace(/f"([^"]*)"/g, (_, content) => {
        const transformed = content.replace(/\{([^}]+)\}/g, (_: string, expr: string) => {
          // Handle format specifiers like {result:.2f}
          const cleanExpr = expr.split(':')[0];
          return `\${${cleanExpr}}`;
        });
        return `\`${transformed}\``;
      });

      // Convert print(...) to env.print(...)
      l = l.replace(/\bprint\s*\(/g, 'env.print(');

      // Convert def my_func(args): to function my_func(args) {
      if (/^\s*def\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*:/.test(l)) {
        l = l.replace(/^\s*def\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*:/, 'function $1($2) {');
      }

      // Convert for x in range(...): to for (let x of env.range(...)) {
      if (/^\s*for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_().]+)\s*:/.test(l)) {
        l = l.replace(/^\s*for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_().]+)\s*:/, 'for (let $1 of $2) {');
      }

      // Convert if / elif / else:
      if (/^\s*if\s+(.+)\s*:/.test(l)) {
        l = l.replace(/^\s*if\s+(.+)\s*:/, 'if ($1) {');
      } else if (/^\s*elif\s+(.+)\s*:/.test(l)) {
        l = l.replace(/^\s*elif\s+(.+)\s*:/, '} else if ($1) {');
      } else if (/^\s*else\s*:/.test(l)) {
        l = l.replace(/^\s*else\s*:/, '} else {');
      }

      // Python True / False / None to JS
      l = l.replace(/\bTrue\b/g, 'true').replace(/\bFalse\b/g, 'false').replace(/\bNone\b/g, 'null');

      jsCode += l + '\n';
    }

    // Auto-close block braces according to indentation or wrap in safe function
    // For simple scripts, let's run in isolated Function
    const runner = new Function('env', `
      try {
        const { print, range, len, sum, max, min } = env;
        ${jsCode}
      } catch(e) {
        env.print("❌ خطأ تنفيذي: " + e.message);
      }
    `);

    runner(simulatedEnv);

    if (logs.length === 0) {
      logs.push('تم تنفيذ البرنامج بنجاح (لا توجد مخرجات طباعة).');
    }

    return {
      output: logs.join('\n'),
      isError: false
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      output: `❌ خطأ في معالجة بايثون:\n${errorMsg}`,
      isError: true,
      rawError: errorMsg
    };
  }
}

export function runSqlCode(code: string): ExecutionResult {
  const logs: string[] = [];
  const lines = code.split(';').map(s => s.trim()).filter(Boolean);

  logs.push('🗄️ محاكي محرك SQLite في كود ماستر AI:');
  logs.push('----------------------------------------');

  for (const statement of lines) {
    const upper = statement.toUpperCase();
    if (upper.startsWith('CREATE TABLE')) {
      const tableName = statement.match(/CREATE\s+TABLE\s+([a-zA-Z0-9_]+)/i)?.[1] || 'الجدول';
      logs.push(`✅ تم إنشاء الجدول [${tableName}] بنجاح.`);
    } else if (upper.startsWith('INSERT INTO')) {
      logs.push('✅ تم إدراج السجلات في قاعدة البيانات بنجاح.');
    } else if (upper.startsWith('SELECT')) {
      logs.push('📊 نتيجة الاستعلام:');
      logs.push('┌─────────┬──────────────┬────────────┐');
      logs.push('│ الطالب   │ النقاط (XP)  │ أيام Streak│');
      logs.push('├─────────┼──────────────┼────────────┤');
      logs.push('│ منى     │ 620          │ 12         │');
      logs.push('│ خالد    │ 450          │ 7          │');
      logs.push('└─────────┴──────────────┴────────────┘');
      logs.push('✅ تم استرجاع صفين في 0.04ms.');
    } else {
      logs.push(`✅ تم تنفيذ الأمر: ${statement.slice(0, 30)}...`);
    }
  }

  return {
    output: logs.join('\n'),
    isError: false
  };
}
