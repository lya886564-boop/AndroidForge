export interface UserProfile {
  name: string;
  avatar: string;
  xp: number;
  level: number;
  streakDays: number;
  lastActiveDate: string;
  completedLessons: string[];
  solvedExercises: string[];
  completedProjects: string[];
  downloadedCourses: string[];
  achievements: string[];
  isPremium: boolean;
}

const STORAGE_KEY = 'codemaster_user_profile_v1';
const SAVED_FILES_KEY = 'codemaster_saved_code_v1';

export const DEFAULT_PROFILE: UserProfile = {
  name: 'المبرمج البطل',
  avatar: '👨‍💻',
  xp: 150,
  level: 1,
  streakDays: 3,
  lastActiveDate: new Date().toISOString().split('T')[0],
  completedLessons: ['py-l1'],
  solvedExercises: ['py-l1'],
  completedProjects: [],
  downloadedCourses: ['python-core'],
  achievements: ['first-step'],
  isPremium: false,
};

export interface Achievement {
  id: string;
  titleAr: string;
  descAr: string;
  icon: string;
  xpReward: number;
}

export const ALL_ACHIEVEMENTS: Achievement[] = [
  { id: 'first-step', titleAr: 'الخطوة الأولى 🚀', descAr: 'أكملت أول درس برمجي في كود ماستر AI', icon: 'Rocket', xpReward: 50 },
  { id: 'python-starter', titleAr: 'مستكشف بايثون 🐍', descAr: 'أتممت 3 دروس في مسار بايثون الشامل', icon: 'Terminal', xpReward: 100 },
  { id: 'web-creator', titleAr: 'مهندس الواجهات 🌐', descAr: 'قمت بتشغيل أول كود HTML و CSS تفاعلي', icon: 'Globe', xpReward: 100 },
  { id: 'streak-master', titleAr: 'المبرمج الملتزم 🔥', descAr: 'حافظت على التعلم اليومي المستمر', icon: 'Flame', xpReward: 150 },
  { id: 'bug-hunter', titleAr: 'صائد الأخطاء 🐞', descAr: 'استخدمت المعلم الذكي أو التشخيص لتصحيح خطأ', icon: 'Bug', xpReward: 80 },
  { id: 'offline-learner', titleAr: 'متعلم دون إنترنت 📲', descAr: 'قمت بتنزيل دورة كاملة للعمل بدون اتصال', icon: 'Download', xpReward: 120 },
  { id: 'project-builder', titleAr: 'صانع المشاريع 🛠️', descAr: 'أنجزت أول مشروع عملي متكامل', icon: 'Wrench', xpReward: 200 }
];

export function getUserProfile(): UserProfile {
  if (typeof window === 'undefined') return DEFAULT_PROFILE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveUserProfile(DEFAULT_PROFILE);
      return DEFAULT_PROFILE;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveUserProfile(profile: UserProfile): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (err) {
    console.error('Failed to save profile', err);
  }
}

export function addXpAndCheckLevel(amount: number): { updated: UserProfile; levelUp: boolean } {
  const profile = getUserProfile();
  const oldLevel = profile.level;
  const newXp = profile.xp + amount;
  // Each level requires 250 XP
  const newLevel = Math.floor(newXp / 250) + 1;

  profile.xp = newXp;
  profile.level = newLevel;

  saveUserProfile(profile);
  return { updated: profile, levelUp: newLevel > oldLevel };
}

export function markLessonCompleted(lessonId: string): UserProfile {
  const profile = getUserProfile();
  if (!profile.completedLessons.includes(lessonId)) {
    profile.completedLessons.push(lessonId);
    profile.xp += 40;
    profile.level = Math.floor(profile.xp / 250) + 1;
    if (!profile.achievements.includes('first-step')) {
      profile.achievements.push('first-step');
    }
    saveUserProfile(profile);
  }
  return profile;
}

export function toggleOfflineDownload(courseId: string): { isDownloaded: boolean; updated: UserProfile } {
  const profile = getUserProfile();
  let isDownloaded = false;
  if (profile.downloadedCourses.includes(courseId)) {
    profile.downloadedCourses = profile.downloadedCourses.filter(id => id !== courseId);
  } else {
    profile.downloadedCourses.push(courseId);
    isDownloaded = true;
    if (!profile.achievements.includes('offline-learner')) {
      profile.achievements.push('offline-learner');
      profile.xp += 120;
    }
  }
  saveUserProfile(profile);
  return { isDownloaded, updated: profile };
}

export function getSavedCode(fileId: string, fallbackCode: string): string {
  if (typeof window === 'undefined') return fallbackCode;
  try {
    const raw = localStorage.getItem(`${SAVED_FILES_KEY}_${fileId}`);
    return raw || fallbackCode;
  } catch {
    return fallbackCode;
  }
}

export function saveCode(fileId: string, code: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(`${SAVED_FILES_KEY}_${fileId}`, code);
  } catch (err) {
    console.error('Failed to save code', err);
  }
}
