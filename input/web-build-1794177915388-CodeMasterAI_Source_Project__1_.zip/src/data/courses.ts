export interface Lesson {
  id: string;
  titleAr: string;
  titleEn: string;
  durationMinutes: number;
  contentAr: string;
  codeSnippet: string;
  language: 'python' | 'html' | 'javascript' | 'sql' | 'kotlin' | 'java';
  exercise: {
    questionAr: string;
    optionsAr: string[];
    correctIndex: number;
    explanationAr: string;
  };
}

export interface Unit {
  id: string;
  titleAr: string;
  descriptionAr: string;
  lessons: Lesson[];
}

export interface Course {
  id: string;
  titleAr: string;
  titleEn: string;
  levelAr: 'مبتدئ' | 'متوسط' | 'متقدم';
  category: 'core' | 'web' | 'mobile' | 'data' | 'tools';
  color: string;
  iconName: string;
  summaryAr: string;
  totalHours: number;
  isPremium?: boolean;
  units: Unit[];
}

export const COURSES: Course[] = [
  {
    id: 'python-core',
    titleAr: 'مسار بايثون الشامل (من الصفر للاحتراف)',
    titleEn: 'Complete Python Mastery',
    levelAr: 'مبتدئ',
    category: 'core',
    color: 'from-amber-500 to-yellow-600',
    iconName: 'Terminal',
    summaryAr: 'تعلم لغة بايثون الأكثر طلباً في العالم: المتغيرات، الدوال، الحلقات التكرارية، وهياكل البيانات وتطبيقات الذكاء الاصطناعي.',
    totalHours: 14,
    units: [
      {
        id: 'py-u1',
        titleAr: 'الوحدة 1: البداية مع بايثون والمتغيرات',
        descriptionAr: 'المفاهيم الأساسية، إخراج النصوص، والمتغيرات وأنواع البيانات.',
        lessons: [
          {
            id: 'py-l1',
            titleAr: 'أول برنامج بايثون ودالة الطباعة',
            titleEn: 'Hello World and print()',
            durationMinutes: 10,
            contentAr: `مرحباً بك في عالم البرمجة بلغة بايثون!
تعتبر بايثون واحدة من أسهل وأقوى لغات البرمجة قراءة وكتابة.

في بايثون، نستخدم دالة \`print()\` لإخراج النصوص والأرقام إلى شاشة المخرجات (Console).

**القواعد الأساسية:**
- النصوص تُوضع بين علامات تنصيص مفردة \`'...\'\` أو مزدوجة \`"..."\`.
- الأرقام تُكتب مباشرة دون علامات تنصيص.
- بايثون حساسة لحالة الأحرف (print تختلف عن Print).`,
            codeSnippet: `# أول سطر برمجي في بايثون
print("مرحباً بك في كود ماستر AI!")
print("Hello, World!")

# طباعة أرقام وحسابات رياضية
print(2026)
print(10 + 5 * 2)`,
            language: 'python',
            exercise: {
              questionAr: 'ما هي النتيجة الصحيحة لتنفيذ الأمر print(4 + 3 * 2) في بايثون؟',
              optionsAr: ['14', '10', '432', 'خطأ برمجي'],
              correctIndex: 1,
              explanationAr: 'في بايثون تُعطى الأولوية للضرب قبل الجمع: (3 * 2 = 6) ثم (4 + 6 = 10).'
            }
          },
          {
            id: 'py-l2',
            titleAr: 'المتغيرات وأنواع البيانات (Variables & Types)',
            titleEn: 'Variables & Data Types',
            durationMinutes: 15,
            contentAr: `المتغيرات (Variables) هي بمثابة صناديق في ذاكرة الجهاز نقوم بتخزين المعلومات بداخلها لنستخدمها لاحقاً.

في بايثون لا تحتاج لتعريف نوع المتغير مسبقاً، فاللغة تتعرف عليه تلقائياً:
- **نص (str):** مثل \`name = "أحمد"\`
- **عدد صحيح (int):** مثل \`age = 22\`
- **عدد عشري (float):** مثل \`gpa = 3.85\`
- **قيمة منطقية (bool):** إما \`True\` أو \`False\``,
            codeSnippet: `# تعريف المتغيرات
student_name = "سارة"
level = 3
score = 94.5
is_enrolled = True

# استخدام المتغيرات في الطباعة
print(f"الطالب: {student_name}")
print(f"المستوى: {level} - النسبة: {score}%")
print(f"مسجل حالياً: {is_enrolled}")`,
            language: 'python',
            exercise: {
              questionAr: 'أي من الأسماء التالية يعتبر اسم متغير غير صالح (Invalid) في بايثون؟',
              optionsAr: ['user_age', '_total', '2nd_score', 'first_name'],
              correctIndex: 2,
              explanationAr: 'في لغة بايثون، لا يجوز أن يبدأ اسم المتغير برقم (مثل 2nd_score).'
            }
          },
          {
            id: 'py-l3',
            titleAr: 'الشروط واتخاذ القرار (if...elif...else)',
            titleEn: 'Conditional Statements',
            durationMinutes: 15,
            contentAr: `تمكنك الشروط من جعل برنامجك يتخذ قرارات ذكية بناءً على معطيات معينة.

نستخدم:
- \`if\` لتنفيذ كود عند تحقق شرط معين.
- \`elif\` لاختبار شرط بديل.
- \`else\` لتنفيذ كود في حال لم يتحقق أي شرط سابق.

**مهم جداً في بايثون:** المسافة البادئة (Indentation) تحدد بداية ونهاية البلوك البرمجي!`,
            codeSnippet: `grade = 88

if grade >= 90:
    print("التقدير: ممتاز (A)")
elif grade >= 80:
    print("التقدير: جيد جداً (B)")
elif grade >= 70:
    print("التقدير: جيد (C)")
else:
    print("يحتاج لمزيد من المذاكرة")`,
            language: 'python',
            exercise: {
              questionAr: 'ماذا سيحدث إذا حذفت المسافة البادئة بعد عبارة if في بايثون؟',
              optionsAr: ['سيعمل الكود بشكل طبيعي', 'سيظهر خطأ IndentationError', 'ستتم طباعة التحذير فقط', 'سيتوقف المتصفح'],
              correctIndex: 1,
              explanationAr: 'المسافة البادئة في بايثون إلزامية نحوية، وحذفها يسبب IndentationError.'
            }
          }
        ]
      },
      {
        id: 'py-u2',
        titleAr: 'الوحدة 2: الحلقات التكرارية والدوال',
        descriptionAr: 'تكرار المهام عبر Loops وبناء دوال قابلة لإعادة الاستخدام.',
        lessons: [
          {
            id: 'py-l4',
            titleAr: 'الحلقات التكرارية (For & While Loops)',
            titleEn: 'Loops in Python',
            durationMinutes: 15,
            contentAr: `بدلاً من تكرار كتابة الكود يدوياً، نستخدم الحلقات التكرارية:
- \`for loop\`: تستخدم عندما تعرف عدد التكرارات أو للتنقل بين عناصر مصفوفة أو مدى رقمي \`range()\`.
- \`while loop\`: تستمر في التكرار طالما أن الشرط صحيح \`True\`.`,
            codeSnippet: `# حلقة for لطباعة الأرقام
for i in range(1, 6):
    print(f"الخطوة رقم: {i}")

# حلقة على قائمة
languages = ["Python", "Kotlin", "JavaScript"]
for lang in languages:
    print(f"أنا أتعلم {lang} في كود ماستر AI")`,
            language: 'python',
            exercise: {
              questionAr: 'كم مرة ستُطبع العبارة في الأمر: for x in range(3): print(x)؟',
              optionsAr: ['مرتين (0, 1)', '3 مرات (0, 1, 2)', '4 مرات (0, 1, 2, 3)', 'مرة واحدة'],
              correctIndex: 1,
              explanationAr: 'الدالة range(3) تولد تسلسلاً من 0 حتى 2 (أي 3 مرات بالضبط).'
            }
          },
          {
            id: 'py-l5',
            titleAr: 'الدوال (Functions) وإعادة استخدام الكود',
            titleEn: 'Functions & Def',
            durationMinutes: 20,
            contentAr: `الدالة (Function) هي كتلة منظمة من الكود تُنفذ مهمة محددة، ويتم تعريفها باستخدام الكلمة المفتاحية \`def\`.

تساعد الدوال على:
1. تجنب تكرار الكود (DRY Principle).
2. تسهيل قراءة وتنظيم البرامج الضخمة.
3. استقبال مدخلات (Parameters) وإرجاع نتائج (Return).`,
            codeSnippet: `def calculate_circle_area(radius):
    pi = 3.14159
    area = pi * (radius ** 2)
    return area

# استدعاء الدالة
r = 5
result = calculate_circle_area(r)
print(f"مساحة الدائرة بنصف قطر {r} هي: {result:.2f}")`,
            language: 'python',
            exercise: {
              questionAr: 'ما الكلمة المفتاحية المستخدمة لإعادة قيمة من الدالة في بايثون؟',
              optionsAr: ['send', 'output', 'return', 'give'],
              correctIndex: 2,
              explanationAr: 'تستخدم الكلمة المفتاحية return لإرجاع ناتج العملية الحسابية أو المتغير من داخل الدالة.'
            }
          }
        ]
      }
    ]
  },
  {
    id: 'web-dev',
    titleAr: 'مسار تطوير الويب الشامل (HTML5, CSS3, JS)',
    titleEn: 'Full-Stack Web Development',
    levelAr: 'مبتدئ',
    category: 'web',
    color: 'from-blue-500 to-cyan-600',
    iconName: 'Globe',
    summaryAr: 'بناء واجهات مواقع الويب التفاعلية: هيكل HTML5، تصميمات CSS3 الجذابة، وبرمجة الجافاسكريبت الحديثة.',
    totalHours: 18,
    units: [
      {
        id: 'web-u1',
        titleAr: 'الوحدة 1: هيكلة صفحات الويب بـ HTML5',
        descriptionAr: 'العناصر، الوسوم، النماذج، والوسائط المتعددة.',
        lessons: [
          {
            id: 'web-l1',
            titleAr: 'مقدمة في HTML5 والعناصر الأساسية',
            titleEn: 'HTML5 Essentials',
            durationMinutes: 12,
            contentAr: `تعتبر HTML (لغة توصيف النص الفائق) الهيكل العظمي لأي موقع على الإنترنت.
تتكون الصفحات من وسوم (Tags) تُفتح بـ \`<tag>\` وتُغلق بـ \`</tag>\`.

العناصر الأساسية:
- العناوين: من \`<h1>\` (الأكبر) إلى \`<h6>\` (الأصغر).
- الفقرات: \`<p>\` لكتابة النصوص.
- الروابط: \`<a href="...">\` للانتقال لصفحات أخرى.
- الأزرار: \`<button>\` للتفاعل.`,
            codeSnippet: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <style>
    body { font-family: sans-serif; padding: 20px; background: #0f172a; color: white; }
    h1 { color: #38bdf8; }
    button { background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; }
  </style>
</head>
<body>
  <h1>مرحباً بك في عالم تطوير الويب!</h1>
  <p>هذه الصفحة تم بناؤها باستخدام HTML5 و CSS3 داخل محرر كود ماستر AI.</p>
  <button onclick="alert('أحسنت! أنت مبرمج ويب الآن 🚀')">اضغط للتجربة</button>
</body>
</html>`,
            language: 'html',
            exercise: {
              questionAr: 'أي من وسوم HTML التالية يُستخدم لإنشاء رابط تشعبي؟',
              optionsAr: ['<link>', '<a>', '<href>', '<url>'],
              correctIndex: 1,
              explanationAr: 'الوسم <a> (Anchor Tag) هو المخصص لإنشاء الروابط في لغة HTML.'
            }
          },
          {
            id: 'web-l2',
            titleAr: 'تنسيق الواجهات بـ CSS3 والأنماط الحديثة',
            titleEn: 'Styling with CSS3',
            durationMinutes: 15,
            contentAr: `تتيح لغة CSS (صفحات الأنماط الانسيابية) تحويل الهيكل البسيط إلى تصميم جذاب وعصري.

المفاهيم المحورية:
- **المحددات (Selectors):** لاختيار العنصر المراد تنسيقه.
- **الألوان والخلفيات:** \`color\` و \`background\`.
- **صندوق النموذج (Box Model):** \`margin\` (الهامش الخارجي)، \`padding\` (الهامش الداخلي)، \`border\` (الحدود).
- **Flexbox:** لتوزيع العناصر بمرونة وسهولة.`,
            codeSnippet: `<!DOCTYPE html>
<html>
<head>
  <style>
    .card-container {
      display: flex;
      gap: 16px;
      justify-content: center;
      padding: 20px;
      background: #111827;
    }
    .card {
      background: #1f2937;
      color: #f9fafb;
      padding: 20px;
      border-radius: 12px;
      border: 1px solid #374151;
      width: 180px;
      text-align: center;
      transition: transform 0.2s;
    }
    .card:hover {
      transform: translateY(-4px);
      border-color: #38bdf8;
    }
  </style>
</head>
<body>
  <div class="card-container">
    <div class="card">
      <h3>بايثون</h3>
      <p>للذكاء الاصطناعي</p>
    </div>
    <div class="card">
      <h3>كوتلن</h3>
      <p>لتطبيقات أندرويد</p>
    </div>
  </div>
</body>
</html>`,
            language: 'html',
            exercise: {
              questionAr: 'ما هي الخاصية المسؤولة عن إضافة مسافة داخلية بين محتوى العنصر وحدوده في CSS؟',
              optionsAr: ['margin', 'padding', 'spacing', 'border'],
              correctIndex: 1,
              explanationAr: 'خاصية padding تُحدد المسافة الداخلية بين المحتوى والحدود، بينما margin هي المسافة الخارجية.'
            }
          }
        ]
      }
    ]
  },
  {
    id: 'android-kotlin',
    titleAr: 'مسار كوتلن وتطوير تطبيقات أندرويد (Kotlin & Android)',
    titleEn: 'Android Development with Kotlin',
    levelAr: 'متوسط',
    category: 'mobile',
    color: 'from-emerald-500 to-teal-600',
    iconName: 'Smartphone',
    summaryAr: 'بناء تطبيقات أندرويد الأصلية الحديثة: لغة كوتلن، دورة حياة التطبيق، وتصميم واجهات Jetpack Compose.',
    totalHours: 20,
    units: [
      {
        id: 'kt-u1',
        titleAr: 'الوحدة 1: أساسيات لغة كوتلن (Kotlin)',
        descriptionAr: 'المتغيرات val و var، دوال كوتلن، والأمان من القيم الفارغة Null Safety.',
        lessons: [
          {
            id: 'kt-l1',
            titleAr: 'المتغيرات في كوتلن (val مقابل var)',
            titleEn: 'Kotlin Variables & Immutability',
            durationMinutes: 12,
            contentAr: `كوتلن هي اللغة الرسمية الأولى الموصى بها من جوجل لتطوير تطبيقات أندرويد.
تتميز بالسرعة العالية وتجنب الأخطاء الشائعة.

في كوتلن نوعان أساسيان من المتغيرات:
1. \`val\` (قيمة ثابتة لا يمكن تغييرها بعد إسنادها - Read Only).
2. \`var\` (متغير يمكن تعديل قيمته لاحقاً).
قاعدة ذهبية في كوتلن: استخدم \`val\` دائماً إلا إذا كنت متأكداً أن القيمة ستتغير!`,
            codeSnippet: `// مثال كود كوتلن في أندرويد
fun main() {
    val appName: String = "كود ماستر AI"
    var activeUsers: Int = 1500
    
    println("تطبيق: $appName")
    println("المستخدمون النشطون: $activeUsers")
    
    // تعديل المتغير var مسموح
    activeUsers += 1
    println("بعد انضمام بطل جديد: $activeUsers")
}`,
            language: 'kotlin',
            exercise: {
              questionAr: 'ماذا يحدث إذا حاولت إعادة إسناد قيمة جديدة لمتغير تم تعريفه بـ val في كوتلن؟',
              optionsAr: ['سيعمل بصورة طبيعية', 'سيحدث خطأ ترجمة Val cannot be reassigned', 'سيتغير نوع المتغير', 'سيتم حذفه'],
              correctIndex: 1,
              explanationAr: 'المتغيرات المعرفة بـ val ثنائية الثبات ولا يمكن تعديل قيمتها بعد الإسناد الأولي.'
            }
          },
          {
            id: 'kt-l2',
            titleAr: 'مقدمة في Jetpack Compose وواجهات أندرويد',
            titleEn: 'Intro to Jetpack Compose',
            durationMinutes: 18,
            contentAr: `Jetpack Compose هي أحدث أدوات جوجل لبناء واجهات أندرويد التفاعلية بطريقة تصريحية (Declarative UI).
بدلاً من ملفات XML القديمة، نقوم بكتابة دوال كوتلن مسبوقة بالتعليق \`@Composable\`.

أهم المكونات:
- \`Text("...")\`: لعرض النصوص.
- \`Button(onClick = { ... })\`: لإنشاء الأزرار.
- \`Column { ... }\`: لترتيب العناصر عمودياً.
- \`Row { ... }\`: لترتيب العناصر أفقياً.`,
            codeSnippet: `// واجهة بسيطة في Jetpack Compose
/*
@Composable
fun WelcomeScreen(userName: String) {
    Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "أهلاً بك يا $userName في كود ماستر!",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = { println("تم النقر!") }) {
            Text("ابدأ التعلم الآن")
        }
    }
}
*/`,
            language: 'kotlin',
            exercise: {
              questionAr: 'ما هو التوجيه المستخدم لتعريف دالة ترسم واجهة في Jetpack Compose؟',
              optionsAr: ['@Layout', '@Composable', '@View', '@Screen'],
              correctIndex: 1,
              explanationAr: 'التوجيه @Composable يخبر مترجم كوتلن أن هذه الدالة مسؤولة عن رسم عناصر واجهة المستخدم.'
            }
          }
        ]
      }
    ]
  },
  {
    id: 'sql-db',
    titleAr: 'مسار قواعد البيانات و SQL',
    titleEn: 'Databases & SQL Mastery',
    levelAr: 'مبتدئ',
    category: 'data',
    color: 'from-purple-500 to-indigo-600',
    iconName: 'Database',
    summaryAr: 'تعلم إدارة قواعد البيانات العلائقية: إنشاء الجداول، الاستعلامات بـ SELECT، والربط JOIN وتعديل البيانات.',
    totalHours: 10,
    units: [
      {
        id: 'sql-u1',
        titleAr: 'الوحدة 1: الاستعلامات الأساسية في SQL',
        descriptionAr: 'SELECT, WHERE, ORDER BY, والتجميع.',
        lessons: [
          {
            id: 'sql-l1',
            titleAr: 'إنشاء الجداول والاستعلام بـ SELECT',
            titleEn: 'Tables & SELECT Queries',
            durationMinutes: 12,
            contentAr: `تعتبر لغة SQL اللغة المعيارية للتخاطب مع قواعد البيانات العلائقية (مثل SQLite و PostgreSQL و MySQL).

أهم الأوامر:
- \`CREATE TABLE\`: لإنشاء جدول جديد مع تحديد الأعمدة وأنواعها.
- \`INSERT INTO\`: لإضافة صفوف جديدة للجدول.
- \`SELECT\`: لجلب وعرض البيانات من جدول معين.`,
            codeSnippet: `-- إنشاء جدول المستخدمين في تطبيق أندرويد
CREATE TABLE students (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    xp INTEGER DEFAULT 0,
    streak_days INTEGER DEFAULT 1
);

-- إدخال بيانات تجريبية
INSERT INTO students (name, xp, streak_days) VALUES 
('خالد', 450, 7),
('منى', 620, 12);

-- استعلام جلب الطلاب المتفوقين
SELECT name, xp, streak_days 
FROM students 
WHERE xp > 500 
ORDER BY xp DESC;`,
            language: 'sql',
            exercise: {
              questionAr: 'أي أمر SQL يُستخدم لترتيب النتائج من الأكبر إلى الأصغر؟',
              optionsAr: ['SORT ASC', 'ORDER BY ... DESC', 'GROUP BY ... TOP', 'FILTER MAX'],
              correctIndex: 1,
              explanationAr: 'يُستخدم أمر ORDER BY مع الكلمة المفتاحية DESC للترتيب التنازلي.'
            }
          }
        ]
      }
    ]
  },
  {
    id: 'git-github',
    titleAr: 'مسار Git و GitHub للمطورين المحترفين',
    titleEn: 'Git & GitHub Version Control',
    levelAr: 'مبتدئ',
    category: 'tools',
    color: 'from-orange-500 to-red-600',
    iconName: 'GitBranch',
    summaryAr: 'التحكم في إصدارات الكود، التعاون البرمجي، الفروع Branches، وإنشاء بورتفوليو احترافي على GitHub.',
    totalHours: 8,
    units: [
      {
        id: 'git-u1',
        titleAr: 'الوحدة 1: أوامر Git الأساسية',
        descriptionAr: 'git init, add, commit, status, push.',
        lessons: [
          {
            id: 'git-l1',
            titleAr: 'أوامر Git الأساسية وحفظ التغييرات',
            titleEn: 'Git Basics & Commits',
            durationMinutes: 10,
            contentAr: `نظام Git هو أداة لا غنى عنها لأي مبرمج لحفظ تاريخ التعديلات والرجوع لأي إصدار سابق عند حدوث خطأ.

الأوامر الأساسية اليومية:
1. \`git init\`: تهيئة مستودع جديد.
2. \`git status\`: معرفة حالة الملفات المعدلة.
3. \`git add .\`: تجهيز الملفات للحفظ (Staging).
4. \`git commit -m "رسالة الحفظ"\`: تسجيل لقطة دائمة للإصدار الحالي.`,
            codeSnippet: `# خطوات حفظ مشروعك على Git
git init
git status
git add .
git commit -m "feat: إطلاق النسخة الأولى من تطبيق كود ماستر AI"
git branch -M main`,
            language: 'javascript',
            exercise: {
              questionAr: 'ما هو الأمر الذي يقوم بتجهيز جميع الملفات المعدلة في Git قبل عمل Commit؟',
              optionsAr: ['git push all', 'git add .', 'git save', 'git prepare'],
              correctIndex: 1,
              explanationAr: 'الأمر git add . يضيف جميع التغييرات في المجلد الحالي إلى منطقة التجهيز (Staging Area).'
            }
          }
        ]
      }
    ]
  },
  {
    id: 'ai-ml',
    titleAr: 'مسار الذكاء الاصطناعي وتعلم الآلة (AI & ML)',
    titleEn: 'AI & Machine Learning Foundations',
    levelAr: 'متوسط',
    category: 'core',
    color: 'from-emerald-400 to-cyan-500',
    iconName: 'Cpu',
    summaryAr: 'فهم نماذج الذكاء الاصطناعي التوليدي، الشبكات العصبية، وهندسة الأوامر Prompt Engineering وربط نماذج Gemini في التطبيقات.',
    totalHours: 12,
    units: [
      {
        id: 'ai-u1',
        titleAr: 'الوحدة 1: مقدمة في الذكاء الاصطناعي التوليدي',
        descriptionAr: 'نماذج اللغات الكبيرة LLMs، هندسة الأوامر، وواجهات البرمجة APIs.',
        lessons: [
          {
            id: 'ai-l1',
            titleAr: 'كيف تفكر النماذج التوليدية (LLMs) واستدعاء Gemini',
            titleEn: 'Generative AI & Gemini API',
            durationMinutes: 15,
            contentAr: `النماذج التوليدية مثل Gemini مبنية على معمارية Transformer وتقوم بتوقع الكلمة التالية الأكثر ملاءمة بناءً على السياق المعطى.

في هذا التطبيق (كود ماستر AI)، قمنا بربط نموذج \`gemini-3.8-flash\` عبر خادم آمن ليقوم بدور المعلم الشخصي لك، ويحلل الكود البرمجي ويشرح الأخطاء باللغة العربية فورياً!`,
            codeSnippet: `# استدعاء خادم المعلم الذكي في التطبيق
async def ask_code_master(prompt_text):
    print(f"جاري إرسال السؤال للمعلم الذكي: {prompt_text}")
    # الرد السحابي الفوري من Gemini
    response = "المعلم الذكي: قمت بفحص الكود، والنتيجة سليمة 100%!"
    return response

print(ask_code_master("كيف أحسن أداء برنامجي؟"))`,
            language: 'python',
            exercise: {
              questionAr: 'ما هي التقنية المسؤولة عن توجيه نماذج الذكاء الاصطناعي لإعطاء أفضل إجابة ممكنة؟',
              optionsAr: ['هندسة الأوامر (Prompt Engineering)', 'مسح الذاكرة العشوائية', 'إعادة تثبيت النظام', 'تشفير قاعدة البيانات'],
              correctIndex: 0,
              explanationAr: 'هندسة الأوامر (Prompt Engineering) هي صياغة وتوجيه المدخلات للحصول على نتائج دقيقة من النموذج.'
            }
          }
        ]
      }
    ]
  }
];
