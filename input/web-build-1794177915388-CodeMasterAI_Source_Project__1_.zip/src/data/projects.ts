export interface PracticalProject {
  id: string;
  titleAr: string;
  titleEn: string;
  categoryAr: string;
  difficultyAr: 'سهل' | 'متوسط' | 'متقدم';
  xpReward: number;
  language: 'python' | 'html' | 'javascript' | 'sql' | 'kotlin';
  summaryAr: string;
  instructionsAr: string[];
  starterCode: string;
  solutionCode: string;
}

export const PRACTICAL_PROJECTS: PracticalProject[] = [
  {
    id: 'calculator-app',
    titleAr: 'مشروع 1: آلة حاسبة ذكية تفاعلية',
    titleEn: 'Interactive Smart Calculator',
    categoryAr: 'تطوير الويب وبايثون',
    difficultyAr: 'سهل',
    xpReward: 120,
    language: 'html',
    summaryAr: 'بناء واجهة آلة حاسبة متكاملة تدعم الجمع والطرح والضرب والقسمة مع أزرار لمسية سريعة.',
    instructionsAr: [
      'قم بتصميم هيكل الآلة الحاسبة وأزرار الأرقام والعمليات الرياضية.',
      'أضف شاشة عرض للنتائج ذات خط واضح ومريح للعين.',
      'قم بربط العمليات الحسابية بواسطة كود جافاسكريبت لحساب النتائج فورياً عند الضغط على =.'
    ],
    starterCode: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <style>
    body { font-family: sans-serif; background: #0b132b; color: #fff; display: flex; justify-content: center; padding: 20px; }
    .calc { background: #1c2541; padding: 20px; border-radius: 16px; width: 280px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
    #display { width: 100%; height: 50px; background: #0b132b; border: 1px solid #3a506b; border-radius: 8px; color: #6fffe9; font-size: 24px; text-align: left; padding: 10px; margin-bottom: 15px; box-sizing: border-box; }
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    button { height: 48px; border-radius: 8px; border: none; background: #3a506b; color: white; font-size: 18px; cursor: pointer; }
    button.op { background: #10b981; }
    button.eq { background: #38bdf8; grid-column: span 2; }
    button.clr { background: #ef4444; }
  </style>
</head>
<body>
  <div class="calc">
    <input type="text" id="display" readonly placeholder="0">
    <div class="grid">
      <button class="clr" onclick="clearDisplay()">C</button>
      <button class="op" onclick="appendChar('/')">÷</button>
      <button class="op" onclick="appendChar('*')">×</button>
      <button class="op" onclick="appendChar('-')">-</button>
      
      <button onclick="appendChar('7')">7</button>
      <button onclick="appendChar('8')">8</button>
      <button onclick="appendChar('9')">9</button>
      <button class="op" onclick="appendChar('+')">+</button>
      
      <button onclick="appendChar('4')">4</button>
      <button onclick="appendChar('5')">5</button>
      <button onclick="appendChar('6')">6</button>
      <button class="op" onclick="appendChar('.')">.</button>
      
      <button onclick="appendChar('1')">1</button>
      <button onclick="appendChar('2')">2</button>
      <button onclick="appendChar('3')">3</button>
      <button onclick="appendChar('0')">0</button>
      
      <button class="eq" onclick="calculate()">=</button>
    </div>
  </div>
  <script>
    const display = document.getElementById('display');
    function appendChar(c) {
      if (display.value === '0') display.value = '';
      display.value += c;
    }
    function clearDisplay() { display.value = ''; }
    function calculate() {
      try {
        display.value = eval(display.value) || '0';
      } catch (e) {
        display.value = 'خطأ';
      }
    }
  </script>
</body>
</html>`,
    solutionCode: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <style>
    body { font-family: sans-serif; background: #0b132b; color: #fff; display: flex; justify-content: center; padding: 20px; }
    .calc { background: #1c2541; padding: 20px; border-radius: 16px; width: 280px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
    #display { width: 100%; height: 50px; background: #0b132b; border: 1px solid #3a506b; border-radius: 8px; color: #6fffe9; font-size: 24px; text-align: left; padding: 10px; margin-bottom: 15px; box-sizing: border-box; }
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    button { height: 48px; border-radius: 8px; border: none; background: #3a506b; color: white; font-size: 18px; cursor: pointer; }
    button.op { background: #10b981; }
    button.eq { background: #38bdf8; grid-column: span 2; font-weight: bold; }
    button.clr { background: #ef4444; }
  </style>
</head>
<body>
  <div class="calc">
    <input type="text" id="display" readonly placeholder="0">
    <div class="grid">
      <button class="clr" onclick="clearDisplay()">C</button>
      <button class="op" onclick="appendChar('/')">÷</button>
      <button class="op" onclick="appendChar('*')">×</button>
      <button class="op" onclick="appendChar('-')">-</button>
      
      <button onclick="appendChar('7')">7</button>
      <button onclick="appendChar('8')">8</button>
      <button onclick="appendChar('9')">9</button>
      <button class="op" onclick="appendChar('+')">+</button>
      
      <button onclick="appendChar('4')">4</button>
      <button onclick="appendChar('5')">5</button>
      <button onclick="appendChar('6')">6</button>
      <button class="op" onclick="appendChar('.')">.</button>
      
      <button onclick="appendChar('1')">1</button>
      <button onclick="appendChar('2')">2</button>
      <button onclick="appendChar('3')">3</button>
      <button onclick="appendChar('0')">0</button>
      
      <button class="eq" onclick="calculate()">=</button>
    </div>
  </div>
  <script>
    const display = document.getElementById('display');
    function appendChar(c) {
      if (display.value === '0') display.value = '';
      display.value += c;
    }
    function clearDisplay() { display.value = ''; }
    function calculate() {
      try {
        display.value = eval(display.value) || '0';
      } catch (e) {
        display.value = 'خطأ';
      }
    }
  </script>
</body>
</html>`
  },
  {
    id: 'portfolio-website',
    titleAr: 'مشروع 2: موقع تعريفي وبورتفوليو شخصي',
    titleEn: 'Personal Developer Portfolio',
    categoryAr: 'تطوير الويب',
    difficultyAr: 'سهل',
    xpReward: 150,
    language: 'html',
    summaryAr: 'بناء موقع شخصي حديث يعرض نبذتك وخبراتك البرمجية ومشاريعك ومعلومات التواصل بأسلوب احترافي.',
    instructionsAr: [
      'إنشاء قسم الترحيب (Hero Section) مع صورة رمزية ومسمى وظيفي.',
      'إنشاء شبكة مهارات (Skills Grid) بلغات البرمجة (Python, Android, Web).',
      'إضافة أزرار تفاعلية للتواصل وحفظ البيانات.'
    ],
    starterCode: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #090d16; color: #f1f5f9; margin: 0; padding: 24px; }
    .hero { text-align: center; padding: 40px 20px; background: linear-gradient(180deg, #131b2e 0%, #090d16 100%); border-radius: 20px; border: 1px solid #1e293b; }
    .avatar { width: 90px; height: 90px; border-radius: 50%; background: #38bdf8; display: flex; align-items: center; justify-content: center; font-size: 36px; margin: 0 auto 16px; border: 4px solid #0ea5e9; }
    h1 { margin: 0 0 8px; color: #fff; font-size: 26px; }
    p.title { color: #38bdf8; margin: 0 0 16px; font-weight: 600; }
    .skills { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; margin-top: 24px; }
    .skill-tag { background: #1e293b; border: 1px solid #334155; padding: 8px 16px; border-radius: 999px; font-size: 14px; }
  </style>
</head>
<body>
  <div class="hero">
    <div class="avatar">👨‍💻</div>
    <h1>أحمد خالد</h1>
    <p class="title">مطور برمجيات وتطبيقات أندرويد معتمد من كود ماستر AI</p>
    <p>أقوم ببناء تطبيقات ذكية وسريعة باستخدام بايثون وكوتلن والويب الحديث.</p>
    
    <div class="skills">
      <div class="skill-tag">Python 🐍</div>
      <div class="skill-tag">Kotlin Android 📱</div>
      <div class="skill-tag">Full-Stack Web 🌐</div>
      <div class="skill-tag">SQL & Data 🗄️</div>
    </div>
  </div>
</body>
</html>`,
    solutionCode: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #090d16; color: #f1f5f9; margin: 0; padding: 24px; }
    .hero { text-align: center; padding: 40px 20px; background: linear-gradient(180deg, #131b2e 0%, #090d16 100%); border-radius: 20px; border: 1px solid #1e293b; }
    .avatar { width: 90px; height: 90px; border-radius: 50%; background: #38bdf8; display: flex; align-items: center; justify-content: center; font-size: 36px; margin: 0 auto 16px; border: 4px solid #0ea5e9; }
    h1 { margin: 0 0 8px; color: #fff; font-size: 26px; }
    p.title { color: #38bdf8; margin: 0 0 16px; font-weight: 600; }
    .skills { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; margin-top: 24px; }
    .skill-tag { background: #1e293b; border: 1px solid #334155; padding: 8px 16px; border-radius: 999px; font-size: 14px; }
  </style>
</head>
<body>
  <div class="hero">
    <div class="avatar">👨‍💻</div>
    <h1>أحمد خالد</h1>
    <p class="title">مطور برمجيات وتطبيقات أندرويد معتمد من كود ماستر AI</p>
    <p>أقوم ببناء تطبيقات ذكية وسريعة باستخدام بايثون وكوتلن والويب الحديث.</p>
    
    <div class="skills">
      <div class="skill-tag">Python 🐍</div>
      <div class="skill-tag">Kotlin Android 📱</div>
      <div class="skill-tag">Full-Stack Web 🌐</div>
      <div class="skill-tag">SQL & Data 🗄️</div>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'todo-app',
    titleAr: 'مشروع 3: تطبيق إدارة المهام اليومية (To-Do)',
    titleEn: 'Interactive Task Manager',
    categoryAr: 'تطوير الويب وجافاسكريبت',
    difficultyAr: 'متوسط',
    xpReward: 180,
    language: 'html',
    summaryAr: 'بناء تطبيق مهام متكامل يتيح إضافة المهام وتحديد المكتمل وحذفها وحفظها محلياً في الذاكرة.',
    instructionsAr: [
      'إنشاء حقل إدخال وزر لإضافة المهام.',
      'تحديث القائمة ديناميكياً عند إضافة مهمة جديدة.',
      'السماح بالنقر على المهمة لشطبها أو الضغط على زر الحذف.'
    ],
    starterCode: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <style>
    body { font-family: sans-serif; background: #090d16; color: #fff; padding: 20px; }
    .box { max-width: 400px; margin: 0 auto; background: #131b2e; padding: 24px; border-radius: 16px; border: 1px solid #1e293b; }
    .input-row { display: flex; gap: 8px; margin-bottom: 16px; }
    input { flex: 1; padding: 12px; border-radius: 8px; border: 1px solid #334155; background: #090d16; color: #fff; }
    button.add-btn { background: #10b981; color: white; border: none; padding: 0 16px; border-radius: 8px; cursor: pointer; font-weight: bold; }
    ul { list-style: none; padding: 0; margin: 0; }
    li { display: flex; align-items: center; justify-content: space-between; padding: 10px; background: #1e293b; border-radius: 8px; margin-bottom: 8px; }
    li.done span { text-decoration: line-through; opacity: 0.5; }
    button.del-btn { background: #ef4444; border: none; color: white; padding: 4px 8px; border-radius: 4px; cursor: pointer; }
  </style>
</head>
<body>
  <div class="box">
    <h2>قائمة مهام المبرمج 🎯</h2>
    <div class="input-row">
      <input type="text" id="taskInput" placeholder="اكتب مهمتك الجديدة...">
      <button class="add-btn" onclick="addTask()">إضافة</button>
    </div>
    <ul id="taskList"></ul>
  </div>
  <script>
    function addTask() {
      const input = document.getElementById('taskInput');
      const text = input.value.trim();
      if (!text) return;
      
      const li = document.createElement('li');
      li.innerHTML = \`<span onclick="this.parentElement.classList.toggle('done')">\${text}</span>
                       <button class="del-btn" onclick="this.parentElement.remove()">حذف</button>\`;
      document.getElementById('taskList').appendChild(li);
      input.value = '';
    }
  </script>
</body>
</html>`,
    solutionCode: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <style>
    body { font-family: sans-serif; background: #090d16; color: #fff; padding: 20px; }
    .box { max-width: 400px; margin: 0 auto; background: #131b2e; padding: 24px; border-radius: 16px; border: 1px solid #1e293b; }
    .input-row { display: flex; gap: 8px; margin-bottom: 16px; }
    input { flex: 1; padding: 12px; border-radius: 8px; border: 1px solid #334155; background: #090d16; color: #fff; }
    button.add-btn { background: #10b981; color: white; border: none; padding: 0 16px; border-radius: 8px; cursor: pointer; font-weight: bold; }
    ul { list-style: none; padding: 0; margin: 0; }
    li { display: flex; align-items: center; justify-content: space-between; padding: 10px; background: #1e293b; border-radius: 8px; margin-bottom: 8px; }
    li.done span { text-decoration: line-through; opacity: 0.5; }
    button.del-btn { background: #ef4444; border: none; color: white; padding: 4px 8px; border-radius: 4px; cursor: pointer; }
  </style>
</head>
<body>
  <div class="box">
    <h2>قائمة مهام المبرمج 🎯</h2>
    <div class="input-row">
      <input type="text" id="taskInput" placeholder="اكتب مهمتك الجديدة...">
      <button class="add-btn" onclick="addTask()">إضافة</button>
    </div>
    <ul id="taskList"></ul>
  </div>
  <script>
    function addTask() {
      const input = document.getElementById('taskInput');
      const text = input.value.trim();
      if (!text) return;
      
      const li = document.createElement('li');
      li.innerHTML = \`<span onclick="this.parentElement.classList.toggle('done')">\${text}</span>
                       <button class="del-btn" onclick="this.parentElement.remove()">حذف</button>\`;
      document.getElementById('taskList').appendChild(li);
      input.value = '';
    }
  </script>
</body>
</html>`
  },
  {
    id: 'python-automation',
    titleAr: 'مشروع 4: أداة أتمتة وتحليل بيانات ببايثون',
    titleEn: 'Python Automation & Analytics Tool',
    categoryAr: 'بايثون وتحليل البيانات',
    difficultyAr: 'متوسط',
    xpReward: 200,
    language: 'python',
    summaryAr: 'بناء سكريبت بايثون لقراءة درجات الطلاب وتحليل المتوسط وتوليد تقرير تفصيلي وإحصائيات النجاح.',
    instructionsAr: [
      'تعريف قاموس يحتوي على أسماء الطلاب ودرجاتهم.',
      'حساب متوسط الدرجات والدرجة العظمى والصغرى.',
      'فرز الطلاب الناجحين وطباعة تقرير منظم.'
    ],
    starterCode: `# أداة أتمتة حساب النتائج وتحليل أداء الطلاب
students_data = [
    {"name": "سارة أحمد", "score": 95},
    {"name": "علي محمد", "score": 82},
    {"name": "خالد عمر", "score": 58},
    {"name": "ريم خالد", "score": 91},
    {"name": "ياسر طارق", "score": 45}
]

def analyze_results(data):
    total = sum(s["score"] for s in data)
    average = total / len(data)
    highest = max(data, key=lambda s: s["score"])
    lowest = min(data, key=lambda s: s["score"])
    
    passed_students = [s for s in data if s["score"] >= 60]
    
    print("=" * 40)
    print(" 📊 تقرير إحصائيات درجات الطلاب - كود ماستر AI")
    print("=" * 40)
    print(f"إجمالي الطلاب: {len(data)}")
    print(f"نسبة النجاح: {(len(passed_students) / len(data)) * 100:.1f}%")
    print(f"المتوسط العام للدرجات: {average:.2f}")
    print(f"أعلى درجة: {highest['name']} ({highest['score']}%)")
    print(f"أقل درجة: {lowest['name']} ({lowest['score']}%)")
    print("=" * 40)

analyze_results(students_data)`,
    solutionCode: `# أداة أتمتة حساب النتائج وتحليل أداء الطلاب
students_data = [
    {"name": "سارة أحمد", "score": 95},
    {"name": "علي محمد", "score": 82},
    {"name": "خالد عمر", "score": 58},
    {"name": "ريم خالد", "score": 91},
    {"name": "ياسر طارق", "score": 45}
]

def analyze_results(data):
    total = sum(s["score"] for s in data)
    average = total / len(data)
    highest = max(data, key=lambda s: s["score"])
    lowest = min(data, key=lambda s: s["score"])
    
    passed_students = [s for s in data if s["score"] >= 60]
    
    print("=" * 40)
    print(" 📊 تقرير إحصائيات درجات الطلاب - كود ماستر AI")
    print("=" * 40)
    print(f"إجمالي الطلاب: {len(data)}")
    print(f"نسبة النجاح: {(len(passed_students) / len(data)) * 100:.1f}%")
    print(f"المتوسط العام للدرجات: {average:.2f}")
    print(f"أعلى درجة: {highest['name']} ({highest['score']}%)")
    print(f"أقل درجة: {lowest['name']} ({lowest['score']}%)")
    print("=" * 40)

analyze_results(students_data)`
  },
  {
    id: 'android-counter-app',
    titleAr: 'مشروع 5: تطبيق أندرويد بكوتلن (عداد واستجابة لمس)',
    titleEn: 'Kotlin Android Counter & State App',
    categoryAr: 'كوتلن وأندرويد',
    difficultyAr: 'متوسط',
    xpReward: 220,
    language: 'kotlin',
    summaryAr: 'بناء نموذج لتطبيق أندرويد باستخدام كوتلن يدير الحالة الرقمية ويسجل عدد النقرات مع حفظ النتيجة.',
    instructionsAr: [
      'فهم إدارة الحالة State في تطبيقات أندرويد الحديثة.',
      'تعريف دالة تفاعلية تحتفظ بالقيمة وتزيدها عند الضغط.',
      'إضافة شرط لمنع النزول تحت الصفر وإعادة التعيين.'
    ],
    starterCode: `// كود كوتلن لتطبيق أندرويد تفاعلي
class CounterViewModel {
    var count: Int = 0
        private set

    fun increment() {
        count += 1
        println("أندرويد: تم زيادة العداد إلى $count 🚀")
    }

    fun decrement() {
        if (count > 0) {
            count -= 1
            println("أندرويد: تم إنقاص العداد إلى $count")
        } else {
            println("تنبيه: لا يمكن النزول تحت الصفر!")
        }
    }

    fun reset() {
        count = 0
        println("أندرويد: تم تصفير العداد بنجاح.")
    }
}

fun main() {
    val vm = CounterViewModel()
    println("بدء تشغيل شاشة أندرويد...")
    vm.increment()
    vm.increment()
    vm.decrement()
    vm.reset()
}`,
    solutionCode: `// كود كوتلن لتطبيق أندرويد تفاعلي
class CounterViewModel {
    var count: Int = 0
        private set

    fun increment() {
        count += 1
        println("أندرويد: تم زيادة العداد إلى $count 🚀")
    }

    fun decrement() {
        if (count > 0) {
            count -= 1
            println("أندرويد: تم إنقاص العداد إلى $count")
        } else {
            println("تنبيه: لا يمكن النزول تحت الصفر!")
        }
    }

    fun reset() {
        count = 0
        println("أندرويد: تم تصفير العداد بنجاح.")
    }
}

fun main() {
    val vm = CounterViewModel()
    println("بدء تشغيل شاشة أندرويد...")
    vm.increment()
    vm.increment()
    vm.decrement()
    vm.reset()
}`
  }
];
