export interface DiagnosticRule {
  id: string;
  pattern: RegExp;
  errorNameAr: string;
  causeAr: string;
  suggestionAr: string;
  exampleFixAr?: string;
}

export const OFFLINE_DIAGNOSTICS: DiagnosticRule[] = [
  {
    id: 'py-indentation',
    pattern: /IndentationError/i,
    errorNameAr: 'خطأ في المسافة البادئة (IndentationError)',
    causeAr: 'في بايثون، لا نستخدم الأقواس المتعرجة {} لتحديد كتل الكود بل نعتمد على المسافات البادئة (عادة 4 مسافات). حدث تفاوت في عدد المسافات في أحد الأسطر.',
    suggestionAr: 'تأكد أن جميع الأسطر التابعة لنفس الدالة أو شرط if أو حلقة for تبدأ بنفس عدد المسافات بالضبط.',
    exampleFixAr: `# الخطأ:
if x > 5:
print("أكبر")

# التصحيح:
if x > 5:
    print("أكبر")`
  },
  {
    id: 'py-syntax-colon',
    pattern: /SyntaxError.*expected ':'|expected ':'/i,
    errorNameAr: 'نسيان النقطتين الرأسيتين (Missing Colon :)',
    causeAr: 'نسيت وضع النقطتين الرأسيتين (:) في نهاية سطر التعريف أو الشرط.',
    suggestionAr: 'ضع نقطتين رأسيتين (:) في نهاية سطور: def, if, elif, else, for, while, class.',
    exampleFixAr: `def my_function(): # لاحظ وجود النقطتين في النهاية`
  },
  {
    id: 'py-name-error',
    pattern: /NameError.*is not defined/i,
    errorNameAr: 'اسم متغير أو دالة غير معرفة (NameError)',
    causeAr: 'حاولت استخدام متغير أو دالة لم تقم بتعريفها مسبقاً، أو يوجد خطأ مطبعي في تهجئة الاسم (حروف كبيرة وصغيرة).',
    suggestionAr: 'تأكد من كتابة اسم المتغير بشكل متطابق وأنك قمت بتعريفه قبل استدعائه في الكود.'
  },
  {
    id: 'py-unclosed-quote',
    pattern: /SyntaxError.*EOL while scanning string literal|unterminated string literal/i,
    errorNameAr: 'علامة تنصيص غير مغلقة (Unterminated String)',
    causeAr: 'بدأت كتابة نص بعلامة تنصيص فردية \' أو مزدوجة " لكنك لم تغلقها في نفس السطر.',
    suggestionAr: 'تأكد من إغلاق كل علامة تنصيص بنفس نوع العلامة التي بدأت بها.'
  },
  {
    id: 'unbalanced-brackets',
    pattern: /SyntaxError.*unexpected EOF while parsing|unmatched '(\)|\}|\])'|closing parenthesis/i,
    errorNameAr: 'أقواس غير متطابقة (Unmatched Brackets)',
    causeAr: 'يوجد قوس مفتوح ( أو { أو [ لم يتم إغلاقه بالشكل الصحيح، أو قمت بإغلاق قوس لم يُفتح.',
    suggestionAr: 'عد الأقواس المفتوحة وتأكد من وجود قوس إغلاق مقابل لكل قوس فتح.'
  },
  {
    id: 'js-reference-error',
    pattern: /ReferenceError.*is not defined/i,
    errorNameAr: 'متغير غير موجود في النطاق (ReferenceError)',
    causeAr: 'في جافاسكريبت، استدعيت متغيراً لم يتم الإعلان عنه باستخدام let أو const أو var.',
    suggestionAr: 'قم بتعريف المتغير أولاً: const myVar = 10;'
  },
  {
    id: 'html-unclosed-tag',
    pattern: /unclosed tag|missing closing tag/i,
    errorNameAr: 'وسم HTML غير مغلق (Unclosed Tag)',
    causeAr: 'قمت بفتح وسم مثل <div> أو <p> أو <button> دون وضع وسم الإغلاق المقابل له </div>.',
    suggestionAr: 'أغلق جميع الوسوم المفتوحة للمحافظة على هيكل الصفحة.'
  }
];

export function diagnoseCodeOffline(code: string, rawError?: string): {
  matched: boolean;
  errorNameAr: string;
  causeAr: string;
  suggestionAr: string;
  exampleFixAr?: string;
} {
  const combined = (rawError || '') + '\n' + code;

  // Check specific error patterns
  for (const rule of OFFLINE_DIAGNOSTICS) {
    if (rule.pattern.test(combined)) {
      return {
        matched: true,
        errorNameAr: rule.errorNameAr,
        causeAr: rule.causeAr,
        suggestionAr: rule.suggestionAr,
        exampleFixAr: rule.exampleFixAr
      };
    }
  }

  // Heuristic checks on raw code
  if (code.includes('if ') && !code.includes(':') && !code.includes('{')) {
    return {
      matched: true,
      errorNameAr: 'ملاحظة نحوية في جملة الشرط',
      causeAr: 'يبدو أنك كتبت جملة شرط if بدون نقطتين (:) في بايثون أو بدون أقواس () في جافاسكريبت.',
      suggestionAr: 'في بايثون اكتب: if x > 0: وفي جافاسكريبت اكتب: if (x > 0) {}'
    };
  }

  // Bracket balance test
  const openParens = (code.match(/\(/g) || []).length;
  const closeParens = (code.match(/\)/g) || []).length;
  if (openParens !== closeParens) {
    return {
      matched: true,
      errorNameAr: 'عدم تطابق في الأقواس الدائرية ()',
      causeAr: `عدد الأقواس المفتوحة (${openParens}) لا يساوي عدد الأقواس المغلقة (${closeParens}).`,
      suggestionAr: 'راجع الأسطر وتأكد من إغلاق كل دالة أو عملية حسابية بقوس إغلاق ) مناسب.'
    };
  }

  return {
    matched: false,
    errorNameAr: 'تحليل الخطأ المحلي',
    causeAr: rawError || 'تم رصد سلوك غير متوقع في الكود.',
    suggestionAr: 'يمكنك الاستعانة بالمعلم الذكي AI للحصول على شرح تفصيلي باللغة العربية واقتراح الكود المصحح.'
  };
}
