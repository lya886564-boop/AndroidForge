import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Sparkles, Copy, Check, Play, Wifi, WifiOff, MessageSquare, Terminal } from 'lucide-react';
import { diagnoseCodeOffline } from '../data/offlineDiagnostics.ts';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  codeSnippet?: string;
  language?: string;
  timestamp: string;
  isOfflineFallback?: boolean;
}

interface AITutorViewProps {
  initialPrompt?: string;
  codeContext?: string;
  languageContext?: string;
  isOnline: boolean;
  onOpenInEditor: (code: string, language: string) => void;
}

const DEFAULT_MESSAGES: ChatMessage[] = [
  {
    id: 'welcome-ai',
    sender: 'ai',
    text: `أهلاً بك يا بطل البرمجة! 🌟
أنا **المعلم الذكي كود ماستر AI**. مهمتي مرافقتك خطوة بخطوة في رحلتك البرمجية:
- شرح الأكواد المعقدة باللغة العربية البسيطة.
- اكتشاف الأخطاء وتصحيحها فورياً.
- مساعدتك في كتابة برامج بايثون وتطبيقات أندرويد والويب.

ما الذي تود تعلمه أو برمجته اليوم؟`,
    timestamp: 'الآن',
  },
];

export const AITutorView: React.FC<AITutorViewProps> = ({
  initialPrompt,
  codeContext,
  languageContext = 'python',
  isOnline,
  onOpenInEditor,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(DEFAULT_MESSAGES);
  const [inputText, setInputText] = useState<string>(initialPrompt || '');
  const [attachedCode, setAttachedCode] = useState<string | undefined>(codeContext);
  const [loading, setLoading] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt) {
      setInputText(initialPrompt);
    }
    if (codeContext) {
      setAttachedCode(codeContext);
    }
  }, [initialPrompt, codeContext]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleCopyCode = (snippet: string, msgId: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedId(msgId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputText;
    if (!textToSend.trim() && !attachedCode) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      codeSnippet: attachedCode,
      language: languageContext,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    // If Offline: use local heuristic diagnostic knowledge base
    if (!isOnline) {
      setTimeout(() => {
        let fallbackReply = 'أنت تعمل حالياً في نمط عدم الاتصال (أوفلاين). ';
        if (attachedCode) {
          const diag = diagnoseCodeOffline(attachedCode, textToSend);
          fallbackReply += `تم فحص الكود محلياً:\n\n**${diag.errorNameAr}**\n${diag.causeAr}\n\n**النصيحة:** ${diag.suggestionAr}`;
          if (diag.exampleFixAr) {
            fallbackReply += `\n\n\`\`\`python\n${diag.exampleFixAr}\n\`\`\``;
          }
        } else {
          fallbackReply += 'للإجابة عن أسئلة جديدة أو مناقشة مواضيع متقدمة، يلزم الاتصال بالإنترنت للتواصل مع نموذج Gemini السحابي.';
        }

        const aiMsg: ChatMessage = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: fallbackReply,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isOfflineFallback: true,
        };

        setMessages((prev) => [...prev, aiMsg]);
        setLoading(false);
      }, 700);
      return;
    }

    // Online: Call Server-Side Gemini API Proxy
    try {
      const response = await fetch('/api/gemini/tutor-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          codeContext: attachedCode,
          language: languageContext,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'فشل الاتصال بالمعلم الذكي');
      }

      // Check if response contains a code block to extract snippet
      const replyText = data.reply || 'تم استلام سؤالك البرمجي.';
      let extractedCode: string | undefined;
      const codeBlockMatch = replyText.match(/```(?:[a-zA-Z0-9]+)?\n([\s\S]*?)```/);
      if (codeBlockMatch) {
        extractedCode = codeBlockMatch[1];
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: replyText,
        codeSnippet: extractedCode,
        language: languageContext,
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: unknown) {
      console.error('Tutor error:', err);
      const errorMsg = err instanceof Error ? err.message : String(err);
      
      // Fallback response with offline advice
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: `تعذر الاتصال بالخادم السحابي مؤقتاً (${errorMsg}). \nيمكنك استخدام بنك تشخيص الأخطاء المدمج في المحرر للعمل دون إنترنت.`,
        timestamp: 'الآن',
        isOfflineFallback: true,
      };
      setMessages((prev) => [...prev, aiMsg]);
    } finally {
      setLoading(false);
      setAttachedCode(undefined);
    }
  };

  const PROMPT_CHIPS = [
    'اشرح لي هذا الكود خطوة بخطوة',
    'اكتشف الأخطاء وحسّن أداء الكود',
    'كيف أبدأ بصنع تطبيق أندرويد حقيقي؟',
    'ما الفرق بين بايثون وجافاسكريبت؟',
  ];

  return (
    <div className="pb-24 max-w-4xl mx-auto px-4 pt-2 flex flex-col h-[calc(100vh-140px)]">
      {/* Top AI Status Banner */}
      <div className="bg-[#101726] border border-slate-800 rounded-xl px-4 py-2.5 mb-3 flex items-center justify-between text-xs shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs">المعلم الذكي (Gemini 3.8 Flash)</h3>
            <p className="text-[11px] text-slate-400">مساعدك البرمجي العربي الشخصي</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {isOnline ? (
            <span className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              <Wifi className="w-3 h-3" />
              <span>جاهز ومتصل سحابياً</span>
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[11px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
              <WifiOff className="w-3 h-3" />
              <span>نمط أوفلاين محلي</span>
            </span>
          )}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-3.5 pr-1 pl-1">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                  isUser
                    ? 'bg-emerald-600 text-white'
                    : 'bg-cyan-950 border border-cyan-700 text-cyan-400'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-emerald-600 text-white rounded-tr-none'
                    : 'bg-[#101726] border border-slate-800 text-slate-200 rounded-tl-none shadow-sm'
                }`}
              >
                {/* Code Attachment if any */}
                {msg.codeSnippet && isUser && (
                  <div className="mb-2 p-2 bg-emerald-700/60 rounded-lg text-left font-mono text-xs overflow-x-auto" dir="ltr">
                    <pre>{msg.codeSnippet}</pre>
                  </div>
                )}

                {/* Text Body */}
                <div className="whitespace-pre-wrap">{msg.text}</div>

                {/* Code Block in AI response */}
                {msg.codeSnippet && !isUser && (
                  <div className="mt-3 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden text-left" dir="ltr">
                    <div className="bg-slate-900/80 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                      <span>{msg.language || 'code'}</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCopyCode(msg.codeSnippet!, msg.id)}
                          className="flex items-center gap-1 hover:text-white transition"
                        >
                          {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedId === msg.id ? 'تم النسخ' : 'نسخ'}</span>
                        </button>
                        <button
                          onClick={() => onOpenInEditor(msg.codeSnippet!, msg.language || 'python')}
                          className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-bold transition"
                        >
                          <Play className="w-3.5 h-3.5 fill-emerald-400" />
                          <span>فتح في المحرر</span>
                        </button>
                      </div>
                    </div>
                    <div className="p-3 text-cyan-300 font-mono text-xs overflow-x-auto">
                      <pre>{msg.codeSnippet}</pre>
                    </div>
                  </div>
                )}

                {/* Timestamp */}
                <div
                  className={`text-[10px] mt-1.5 text-right ${
                    isUser ? 'text-emerald-200' : 'text-slate-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-2.5 items-center text-xs text-slate-400">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-[#101726] border border-slate-800 rounded-2xl rounded-tl-none px-4 py-2.5 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>المعلم الذكي يفكر ويكتب الإجابة باللغة العربية...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompt Chips */}
      <div className="py-2 flex items-center gap-2 overflow-x-auto scrollbar-none shrink-0">
        {PROMPT_CHIPS.map((chip, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(chip)}
            className="bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-[11px] font-medium px-3 py-1.5 rounded-full whitespace-nowrap shrink-0 transition"
          >
            {chip}
          </button>
        ))}
      </div>

      {/* Attached Context Badge if present */}
      {attachedCode && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 mb-2 flex items-center justify-between text-xs text-slate-300 shrink-0">
          <div className="flex items-center gap-2 truncate">
            <Terminal className="w-3.5 h-3.5 text-cyan-400" />
            <span className="truncate">كود مرفق من المحرر ({languageContext})</span>
          </div>
          <button
            onClick={() => setAttachedCode(undefined)}
            className="text-[11px] text-rose-400 hover:text-rose-300 shrink-0"
          >
            إلغاء الإرفاق
          </button>
        </div>
      )}

      {/* Input Box Bar */}
      <div className="bg-[#101726] border border-slate-800 rounded-2xl p-2 flex items-center gap-2 shrink-0">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
          placeholder="اسأل المعلم الذكي عن أي مفهوم برمجي أو كود..."
          className="flex-1 bg-transparent text-white text-xs sm:text-sm px-3 py-1.5 focus:outline-none placeholder:text-slate-500"
        />

        <button
          onClick={() => handleSendMessage()}
          disabled={loading || (!inputText.trim() && !attachedCode)}
          className="w-9 h-9 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white flex items-center justify-center shrink-0 transition"
        >
          <Send className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
