import React, { useState, useEffect } from 'react';
import { Flame, Zap, Wifi, WifiOff, Download, Smartphone } from 'lucide-react';
import { UserProfile } from '../utils/storage.ts';

interface HeaderProps {
  profile: UserProfile;
  onOpenApkModal: () => void;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({ profile, onOpenApkModal, isOnline }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true;
    setIsInstalled(isStandalone);

    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallPwa = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      onOpenApkModal();
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#090d16]/95 backdrop-blur-md border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Brand Lockup */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-emerald-500 p-[1.5px] shadow-sm shadow-cyan-500/10">
            <div className="w-full h-full bg-[#090d16] rounded-[10px] flex items-center justify-center">
              <span className="text-emerald-400 font-mono font-bold text-sm tracking-tighter">&lt;/&gt;</span>
            </div>
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight leading-tight flex items-center gap-1.5">
              <span>كود ماستر AI</span>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.2 rounded font-mono">
                أندرويد
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 hidden sm:block">أكاديمية البرمجة الذكية</p>
          </div>
        </div>

        {/* Status Indicators & Stats */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Online/Offline Status */}
          <div 
            title={isOnline ? 'متصل بنموذج Gemini السحابي' : 'يعمل بنمط بدون اتصال (أوفلاين)'}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium border ${
              isOnline 
                ? 'bg-slate-900/60 border-slate-800 text-slate-300' 
                : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden md:inline text-[11px]">سحابي AI</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px]">أوفلاين</span>
              </>
            )}
          </div>

          {/* Streak Badge */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg text-xs text-amber-400 font-semibold shadow-sm">
            <Flame className="w-4 h-4 fill-amber-500 text-amber-500 animate-pulse" />
            <span className="font-mono tabular-nums">{profile.streakDays}</span>
            <span className="text-slate-400 text-[10px] hidden sm:inline">أيام</span>
          </div>

          {/* XP & Level Badge */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg text-xs text-cyan-400 font-semibold shadow-sm">
            <Zap className="w-3.5 h-3.5 fill-cyan-400 text-cyan-400" />
            <span className="font-mono tabular-nums">{profile.xp}</span>
            <span className="text-[10px] text-slate-400 hidden sm:inline">XP</span>
          </div>

          {/* Install / Download APK Action Button */}
          <button
            onClick={onOpenApkModal}
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-sm shadow-emerald-500/20 active:scale-95 transition-all whitespace-nowrap shrink-0"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">تحميل APK</span>
            <span className="text-[10px] bg-white/20 px-1 rounded font-mono">20MB</span>
          </button>
        </div>
      </div>
    </header>
  );
};
