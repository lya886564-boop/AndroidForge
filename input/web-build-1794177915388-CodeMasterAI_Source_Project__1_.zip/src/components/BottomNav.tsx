import React from 'react';
import { LayoutDashboard, GraduationCap, Code2, Bot, Award } from 'lucide-react';

export type TabType = 'dashboard' | 'academy' | 'editor' | 'tutor' | 'projects';

interface BottomNavProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onSelectTab }) => {
  const tabs: { id: TabType; labelAr: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'dashboard', labelAr: 'الرئيسية', icon: LayoutDashboard },
    { id: 'academy', labelAr: 'الأكاديمية', icon: GraduationCap },
    { id: 'editor', labelAr: 'المحرر', icon: Code2 },
    { id: 'tutor', labelAr: 'المعلم الذكي', icon: Bot },
    { id: 'projects', labelAr: 'المشاريع', icon: Award },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#090d16]/95 backdrop-blur-md border-t border-slate-800/80 pb-safe">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center py-1 transition-all relative ${
                isActive ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200 font-medium'
              }`}
            >
              <div
                className={`p-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-emerald-500/15 text-emerald-400 scale-105' : 'bg-transparent'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-[11px] tracking-tight mt-0.5 whitespace-nowrap">
                {tab.labelAr}
              </span>
              {isActive && (
                <span className="absolute top-1 w-1 h-1 rounded-full bg-emerald-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
