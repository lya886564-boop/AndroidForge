import React from 'react';
import { Play, Sparkles, Terminal, Globe, Smartphone, Database, GitBranch, Cpu, CheckCircle2, ArrowLeft, Flame, Award } from 'lucide-react';
import { UserProfile } from '../utils/storage.ts';
import { COURSES, Course } from '../data/courses.ts';
import { PRACTICAL_PROJECTS } from '../data/projects.ts';
import { TabType } from './BottomNav.tsx';

interface DashboardViewProps {
  profile: UserProfile;
  onNavigateTab: (tab: TabType) => void;
  onSelectCourse: (courseId: string) => void;
  onOpenProject: (projectId: string) => void;
  onOpenApkModal: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  onNavigateTab,
  onSelectCourse,
  onOpenProject,
  onOpenApkModal,
}) => {
  const currentCourse = COURSES[0]; // Python default
  const xpInCurrentLevel = profile.xp % 250;
  const levelProgressPercent = Math.min(100, Math.round((xpInCurrentLevel / 250) * 100));

  const getCourseIcon = (name: string) => {
    switch (name) {
      case 'Terminal': return Terminal;
      case 'Globe': return Globe;
      case 'Smartphone': return Smartphone;
      case 'Database': return Database;
      case 'GitBranch': return GitBranch;
      case 'Cpu': return Cpu;
      default: return Terminal;
    }
  };

  return (
    <div className="space-y-6 pb-20 max-w-6xl mx-auto px-4 pt-4">
      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#121c33] via-[#0e172a] to-[#090d16] border border-slate-800/80 p-5 sm:p-6 shadow-xl">
        <div className="absolute -top-12 -left-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-semibold">
                أكاديمية كود ماستر AI
              </span>
              <span className="text-xs text-slate-400">· المستمر لليوم {profile.streakDays}</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              مرحباً بك يا {profile.name} 👋
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
              تعلم بايثون وتطوير تطبيقات أندرويد والويب مع محرر الكود المباشر والمعلم الذكي بدون الحاجة لإنترنت دائم.
            </p>

            {/* Quick Resume & Direct APK Download CTA */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => {
                  onSelectCourse('python-core');
                  onNavigateTab('academy');
                }}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/20 active:scale-95 transition"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>متابعة التعلم (مسار بايثون)</span>
              </button>

              <button
                onClick={() => onNavigateTab('editor')}
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl border border-slate-700 transition"
              >
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span>فتح محرر الأكواد</span>
              </button>
            </div>
          </div>

          {/* Level Progress Widget */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 min-w-[220px] shrink-0 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">المستوى الحالي:</span>
              <span className="text-cyan-400 font-bold text-sm">مستوى {profile.level}</span>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${levelProgressPercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>{xpInCurrentLevel} XP</span>
                <span>{250} XP للترقية</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[11px]">
              <span className="text-slate-400 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>الالتزام اليومي:</span>
              </span>
              <span className="text-amber-400 font-bold">{profile.streakDays} أيام 🔥</span>
            </div>
          </div>
        </div>
      </div>

      {/* Prominent Direct APK Download Card */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900 to-teal-950/70 border-2 border-emerald-500/40 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg shadow-emerald-950/50">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
              <span>تنزيل تطبيق أندرويد الرسمي (CodeMasterAI-v1.0.apk)</span>
              <span className="text-[11px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                20 MB
              </span>
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              اضغط الزر الأخضر لتنزيل ملف التثبيت مباشرة إلى هاتفك بنقرة واحدة ودون الحاجة لأي مواقع خارجية.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenApkModal}
          className="flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg shadow-emerald-600/30 active:scale-95 transition shrink-0 whitespace-nowrap cursor-pointer"
        >
          <Smartphone className="w-4 h-4" />
          <span>تنزيل ملف APK الآن (20MB)</span>
        </button>
      </div>

      {/* Main Tracks Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white">المسارات التعليمية المتاحة</h3>
            <p className="text-xs text-slate-400">مناهج متكاملة باللغة العربية من الصفر حتى بناء المشاريع</p>
          </div>
          <button
            onClick={() => onNavigateTab('academy')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 transition"
          >
            <span>عرض الكل</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {COURSES.map((course) => {
            const Icon = getCourseIcon(course.iconName);
            const isCompleted = profile.downloadedCourses.includes(course.id);

            return (
              <div
                key={course.id}
                onClick={() => {
                  onSelectCourse(course.id);
                  onNavigateTab('academy');
                }}
                className="group cursor-pointer bg-[#101726] hover:bg-[#141d30] border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all duration-200 flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-900 text-slate-300 border border-slate-800">
                        {course.levelAr}
                      </span>
                      {isCompleted && (
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>أوفلاين</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-white group-hover:text-emerald-400 transition">
                      {course.titleAr}
                    </h4>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                      {course.summaryAr}
                    </p>
                  </div>
                </div>

                <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span>{course.units.length} وحدات تعليمية</span>
                  <span className="text-emerald-400 font-medium group-hover:translate-x-1 transition flex items-center gap-1">
                    <span>ابدأ الدرس</span>
                    <ArrowLeft className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Practical Projects Spotlight */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white">المشاريع العملية الجاهزة للتطبيق</h3>
            <p className="text-xs text-slate-400">تطبيقات حقيقية تعمل مباشرة داخل محرر الكود في التطبيق</p>
          </div>
          <button
            onClick={() => onNavigateTab('projects')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1 transition"
          >
            <span>جميع المشاريع</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {PRACTICAL_PROJECTS.slice(0, 3).map((proj) => (
            <div
              key={proj.id}
              onClick={() => onOpenProject(proj.id)}
              className="cursor-pointer bg-[#101726] border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-400">{proj.categoryAr}</span>
                  <span className="text-amber-400 font-bold font-mono">+{proj.xpReward} XP</span>
                </div>
                <h4 className="text-sm font-bold text-white mb-1">{proj.titleAr}</h4>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{proj.summaryAr}</p>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">{proj.difficultyAr}</span>
                <span className="text-cyan-400 font-medium">جرب المشروع الآن ←</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Free & Offline Guarantee Banner */}
      <div className="rounded-xl bg-slate-900/60 border border-slate-800 p-3.5 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>المحتوى الأساسي والمشاريع مجانية بالكامل وتعمل دون اتصال (أوفلاين) بدون اشتراك إجباري.</span>
        </div>
      </div>
    </div>
  );
};
