import React, { useState } from 'react';
import { 
  Award, 
  Terminal, 
  Play, 
  CheckCircle2, 
  Flame, 
  Zap, 
  Download, 
  Share2, 
  Sparkles, 
  BookOpen, 
  Smartphone,
  Shield,
  Layers,
  FileCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PRACTICAL_PROJECTS, PracticalProject } from '../data/projects.ts';
import { UserProfile, ALL_ACHIEVEMENTS } from '../utils/storage.ts';

interface ProjectsViewProps {
  profile: UserProfile;
  onOpenProjectInEditor: (code: string, language: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({ profile, onOpenProjectInEditor }) => {
  const [subTab, setSubTab] = useState<'projects' | 'achievements' | 'certificate'>('projects');
  const [selectedProject, setSelectedProject] = useState<PracticalProject | null>(null);
  const [showCertConfetti, setShowCertConfetti] = useState(false);

  const handleTriggerCertificate = () => {
    setShowCertConfetti(true);
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });
    } catch (e) {}
    setTimeout(() => setShowCertConfetti(false), 2000);
  };

  return (
    <div className="pb-24 max-w-6xl mx-auto px-4 pt-3 space-y-4">
      {/* Sub Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setSubTab('projects')}
          className={`flex items-center gap-2 text-xs sm:text-sm font-bold px-3.5 py-2 rounded-xl transition ${
            subTab === 'projects'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900/60'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>المشاريع العملية</span>
        </button>

        <button
          onClick={() => setSubTab('achievements')}
          className={`flex items-center gap-2 text-xs sm:text-sm font-bold px-3.5 py-2 rounded-xl transition ${
            subTab === 'achievements'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900/60'
          }`}
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span>الإنجازات والإحصائيات</span>
        </button>

        <button
          onClick={() => {
            setSubTab('certificate');
            handleTriggerCertificate();
          }}
          className={`flex items-center gap-2 text-xs sm:text-sm font-bold px-3.5 py-2 rounded-xl transition ${
            subTab === 'certificate'
              ? 'bg-cyan-600 text-white'
              : 'text-slate-400 hover:text-white bg-slate-900/60'
          }`}
        >
          <FileCheck className="w-4 h-4 text-cyan-400" />
          <span>الشهادة المعتمدة</span>
        </button>
      </div>

      {/* 1. Practical Projects View */}
      {subTab === 'projects' && (
        <div className="space-y-4">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white">المشاريع البرمجية التطبيقية</h2>
            <p className="text-xs text-slate-400">
              كل مشروع يحتوي على الإرشادات والكود المصدري الكامل القابل للتشغيل والتعديل فوراً داخل التطبيق.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {PRACTICAL_PROJECTS.map((project) => (
              <div
                key={project.id}
                className="bg-[#101726] border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-emerald-400 font-semibold">{project.categoryAr}</span>
                    <span className="text-amber-400 font-bold font-mono">+{project.xpReward} XP</span>
                  </div>

                  <h3 className="text-base font-bold text-white">{project.titleAr}</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{project.summaryAr}</p>

                  {/* Instructions Highlights */}
                  <div className="mt-3 bg-slate-950/80 rounded-xl p-3 border border-slate-800/80 text-xs text-slate-300 space-y-1.5">
                    <span className="font-semibold text-slate-200">الخطوات الأساسية:</span>
                    <ul className="list-disc list-inside text-slate-400 text-[11px] space-y-0.5 pr-1">
                      {project.instructionsAr.map((step, idx) => (
                        <li key={idx} className="leading-normal">{step}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                  <span className="text-[11px] px-2.5 py-1 rounded-full bg-slate-900 text-slate-400 border border-slate-800">
                    مستوى الصعوبة: {project.difficultyAr}
                  </span>

                  <button
                    onClick={() => onOpenProjectInEditor(project.solutionCode, project.language)}
                    className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-md transition"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>تشغيل المشروع في المحرر</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. Achievements & Stats View */}
      {subTab === 'achievements' && (
        <div className="space-y-5">
          {/* Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#101726] border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs text-slate-400">إجمالي النقاط (XP)</span>
              <div className="text-xl font-mono font-bold text-cyan-400 mt-1">{profile.xp}</div>
            </div>
            <div className="bg-[#101726] border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs text-slate-400">المستوى الحالي</span>
              <div className="text-xl font-bold text-emerald-400 mt-1">مستوى {profile.level}</div>
            </div>
            <div className="bg-[#101726] border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs text-slate-400">الالتزام اليومي (Streak)</span>
              <div className="text-xl font-bold text-amber-400 mt-1">{profile.streakDays} أيام 🔥</div>
            </div>
            <div className="bg-[#101726] border border-slate-800 rounded-xl p-4 text-center">
              <span className="text-xs text-slate-400">الدروس المكتملة</span>
              <div className="text-xl font-mono font-bold text-purple-400 mt-1">{profile.completedLessons.length}</div>
            </div>
          </div>

          {/* Badges Gallery */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-white">أوسمة الشرف والإنجازات البرمجية</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {ALL_ACHIEVEMENTS.map((ach) => {
                const isUnlocked = profile.achievements.includes(ach.id);
                return (
                  <div
                    key={ach.id}
                    className={`rounded-xl p-4 border transition flex items-center gap-3.5 ${
                      isUnlocked
                        ? 'bg-[#101726] border-emerald-500/30'
                        : 'bg-slate-900/40 border-slate-800/80 opacity-60'
                    }`}
                  >
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl shrink-0 ${
                        isUnlocked
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      <Award className="w-6 h-6" />
                    </div>

                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white">{ach.titleAr}</h4>
                        {isUnlocked && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-tight">{ach.descAr}</p>
                      <span className="text-[10px] text-amber-400 font-mono font-semibold">
                        +{ach.xpReward} XP
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. Certificate of Completion */}
      {subTab === 'certificate' && (
        <div className="space-y-4">
          <div className="text-center space-y-1">
            <h2 className="text-lg font-bold text-white">شهادة إتمام معتمدة</h2>
            <p className="text-xs text-slate-400">شهادة رسمية صادرة من أكاديمية كود ماستر AI لتأكيد إنجازك البرمجي</p>
          </div>

          {/* Certificate Canvas Frame */}
          <div className="max-w-2xl mx-auto bg-gradient-to-br from-[#0c1527] via-[#10192e] to-[#090d16] border-4 border-amber-500/30 rounded-3xl p-8 sm:p-10 shadow-2xl relative overflow-hidden text-center space-y-5">
            {/* Watermark Pattern */}
            <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center font-mono text-9xl">
              &lt;/&gt;
            </div>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-xs text-amber-400 font-bold uppercase tracking-wider bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5" />
                <span>شهادة إتقان وتفوق برمجي</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white pt-2">
                كود ماستر AI — Code Master AI
              </h3>
            </div>

            <p className="text-xs text-slate-300">تشهد الأكاديمية بأن المبرمج المتميز:</p>

            <div className="text-xl sm:text-2xl font-black text-cyan-400 border-b border-cyan-500/30 pb-2 inline-block px-8">
              {profile.name}
            </div>

            <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
              قد أتم بنجاح متطلبات المسار التأسيسي والتطبيقي وحل التمارين البرمجية وبناء المشاريع العملية في برمجة بايثون وتطبيقات أندرويد والويب الحديث.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-around gap-4 text-xs text-slate-400 border-t border-slate-800">
              <div>
                <span className="block text-[10px] text-slate-500">تاريخ الإصدار:</span>
                <span className="font-mono text-slate-200">{new Date().toLocaleDateString('ar-EG')}</span>
              </div>
              <div>
                <span className="block text-[10px] text-slate-500">رقم الاعتماد:</span>
                <span className="font-mono text-emerald-400">CMAI-2026-984</span>
              </div>
              <div>
                <span className="block text-[10px] text-slate-500">الرصيد المنجز:</span>
                <span className="font-mono text-amber-400">{profile.xp} XP (مستوى {profile.level})</span>
              </div>
            </div>
          </div>

          <div className="text-center pt-2">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg transition"
            >
              <Download className="w-4 h-4" />
              <span>طباعة وحفظ الشهادة (PDF)</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
