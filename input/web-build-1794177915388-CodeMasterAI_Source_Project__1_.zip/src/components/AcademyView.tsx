import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Download, 
  Play, 
  Terminal, 
  ArrowLeft, 
  HelpCircle, 
  Sparkles, 
  BookOpen, 
  ArrowRight,
  Check,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { COURSES, Course, Lesson } from '../data/courses.ts';
import { UserProfile, markLessonCompleted, toggleOfflineDownload, addXpAndCheckLevel } from '../utils/storage.ts';

interface AcademyViewProps {
  profile: UserProfile;
  selectedCourseId: string;
  onSelectCourse: (id: string) => void;
  onOpenInEditor: (code: string, language: string) => void;
  onProfileUpdated: (updated: UserProfile) => void;
}

export const AcademyView: React.FC<AcademyViewProps> = ({
  profile,
  selectedCourseId,
  onSelectCourse,
  onOpenInEditor,
  onProfileUpdated,
}) => {
  const currentCourse = COURSES.find((c) => c.id === selectedCourseId) || COURSES[0];
  const [activeLesson, setActiveLesson] = useState<Lesson>(
    currentCourse.units[0]?.lessons[0] || COURSES[0].units[0].lessons[0]
  );
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);

  const isCurrentCourseDownloaded = profile.downloadedCourses.includes(currentCourse.id);
  const isLessonCompleted = profile.completedLessons.includes(activeLesson.id);

  const handleToggleDownload = () => {
    const { isDownloaded, updated } = toggleOfflineDownload(currentCourse.id);
    onProfileUpdated(updated);
    setDownloadSuccessToast(
      isDownloaded
        ? `تم تنزيل دورة "${currentCourse.titleAr}" بنجاح للعمل بدون إنترنت 📲`
        : `تمت إزالة دورة "${currentCourse.titleAr}" من الذاكرة المحلية.`
    );
    setTimeout(() => setDownloadSuccessToast(null), 3000);
  };

  const handleQuizSubmit = () => {
    if (selectedQuizOption === null) return;
    setQuizSubmitted(true);

    if (selectedQuizOption === activeLesson.exercise.correctIndex) {
      // Confetti burst for correct answer!
      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch (e) {
        // Safe fallback
      }

      // Mark lesson complete and award XP
      const updated = markLessonCompleted(activeLesson.id);
      onProfileUpdated(updated);
    }
  };

  const handleResetQuiz = () => {
    setSelectedQuizOption(null);
    setQuizSubmitted(false);
  };

  const handleSelectLesson = (lesson: Lesson) => {
    setActiveLesson(lesson);
    setSelectedQuizOption(null);
    setQuizSubmitted(false);
  };

  return (
    <div className="pb-24 max-w-6xl mx-auto px-4 pt-3 space-y-4">
      {/* Toast Notification */}
      {downloadSuccessToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{downloadSuccessToast}</span>
        </div>
      )}

      {/* Courses Horizontal Tabs Scroller */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-none">
        {COURSES.map((course) => {
          const isSelected = course.id === currentCourse.id;
          return (
            <button
              key={course.id}
              onClick={() => {
                onSelectCourse(course.id);
                setActiveLesson(course.units[0]?.lessons[0] || activeLesson);
                setSelectedQuizOption(null);
                setQuizSubmitted(false);
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition shrink-0 ${
                isSelected
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
              }`}
            >
              <span>{course.titleAr.split(' ')[1] || course.titleAr}</span>
            </button>
          );
        })}
      </div>

      {/* Course Banner */}
      <div className="bg-[#101726] border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs mb-1">
            <span className="text-emerald-400 font-semibold">{currentCourse.titleEn}</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-400">{currentCourse.levelAr}</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white">{currentCourse.titleAr}</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">{currentCourse.summaryAr}</p>
        </div>

        {/* Offline Download Button */}
        <button
          onClick={handleToggleDownload}
          className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold border transition shrink-0 ${
            isCurrentCourseDownloaded
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
          }`}
        >
          {isCurrentCourseDownloaded ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>محفوظ للعمل أوفلاين</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>تحميل الدورة أوفلاين</span>
            </>
          )}
        </button>
      </div>

      {/* Main Split: Lesson Content (70%) + Curriculum Units Drawer (30%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Active Lesson Viewer (lg:col-span-8) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-[#101726] border border-slate-800 rounded-2xl p-5 space-y-5">
            {/* Lesson Title Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                  <span className="font-mono text-cyan-400">{activeLesson.titleEn}</span>
                  <span>·</span>
                  <span>{activeLesson.durationMinutes} دقيقة</span>
                </div>
                <h3 className="text-base sm:text-lg font-bold text-white">{activeLesson.titleAr}</h3>
              </div>

              {isLessonCompleted && (
                <div className="flex items-center gap-1.5 text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded-lg shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>مكتمل</span>
                </div>
              )}
            </div>

            {/* Lesson Arabic Text Content */}
            <div className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line space-y-2">
              {activeLesson.contentAr}
            </div>

            {/* Code Snippet Box */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>كود المثال التوضيحي ({activeLesson.language})</span>
                </span>
                <button
                  onClick={() => onOpenInEditor(activeLesson.codeSnippet, activeLesson.language)}
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs px-3 py-1.5 rounded-lg active:scale-95 transition"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>تشغيل الكود في المحرر</span>
                </button>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 overflow-x-auto text-left font-mono text-xs text-cyan-300 leading-normal" dir="ltr">
                <pre>{activeLesson.codeSnippet}</pre>
              </div>
            </div>

            {/* Interactive Exercise / Quiz Section */}
            <div className="mt-6 pt-5 border-t border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <HelpCircle className="w-4 h-4 text-amber-400" />
                <span>اختبر فهمك للدرس (+40 XP):</span>
              </div>

              <p className="text-xs sm:text-sm text-slate-200">{activeLesson.exercise.questionAr}</p>

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {activeLesson.exercise.optionsAr.map((option, idx) => {
                  const isSelected = selectedQuizOption === idx;
                  const isCorrect = idx === activeLesson.exercise.correctIndex;
                  let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700';

                  if (quizSubmitted) {
                    if (isCorrect) {
                      btnStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold';
                    } else if (isSelected && !isCorrect) {
                      btnStyle = 'bg-rose-500/20 border-rose-500 text-rose-300';
                    }
                  } else if (isSelected) {
                    btnStyle = 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-semibold';
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => !quizSubmitted && setSelectedQuizOption(idx)}
                      disabled={quizSubmitted}
                      className={`text-right p-3 rounded-xl border text-xs sm:text-sm transition flex items-center justify-between gap-2 ${btnStyle}`}
                    >
                      <span>{option}</span>
                      {quizSubmitted && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Submit / Reset Actions */}
              <div className="flex items-center justify-between pt-2">
                {!quizSubmitted ? (
                  <button
                    onClick={handleQuizSubmit}
                    disabled={selectedQuizOption === null}
                    className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-bold text-xs px-4 py-2 rounded-xl transition"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>تحقق من الإجابة واستلم النقاط</span>
                  </button>
                ) : (
                  <button
                    onClick={handleResetQuiz}
                    className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>إعادة المحاولة</span>
                  </button>
                )}
              </div>

              {/* Quiz Explanation Feedback */}
              {quizSubmitted && (
                <div
                  className={`p-3 rounded-xl text-xs space-y-1 ${
                    selectedQuizOption === activeLesson.exercise.correctIndex
                      ? 'bg-emerald-950/60 border border-emerald-800 text-emerald-200'
                      : 'bg-rose-950/60 border border-rose-800 text-rose-200'
                  }`}
                >
                  <p className="font-bold">
                    {selectedQuizOption === activeLesson.exercise.correctIndex
                      ? '🎉 إجابة صحيحة! أحسنت صنعاً (+40 XP)'
                      : '❌ إجابة غير دقيقة. انظر الشرح بالأسفل:'}
                  </p>
                  <p className="leading-relaxed text-slate-300">{activeLesson.exercise.explanationAr}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Curriculum Units & Lessons Navigation (lg:col-span-4) */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>وحدات ودروس المسار</span>
          </h3>

          <div className="space-y-3">
            {currentCourse.units.map((unit, uIdx) => (
              <div key={unit.id} className="bg-[#101726] border border-slate-800 rounded-xl overflow-hidden">
                <div className="p-3 bg-slate-900/60 border-b border-slate-800/80">
                  <h4 className="text-xs font-bold text-slate-200">{unit.titleAr}</h4>
                  <p className="text-[11px] text-slate-400">{unit.descriptionAr}</p>
                </div>

                <div className="divide-y divide-slate-800/60">
                  {unit.lessons.map((lesson) => {
                    const isSelected = lesson.id === activeLesson.id;
                    const isCompleted = profile.completedLessons.includes(lesson.id);

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => handleSelectLesson(lesson)}
                        className={`w-full text-right p-3 flex items-center justify-between text-xs transition ${
                          isSelected
                            ? 'bg-emerald-500/10 text-emerald-400 font-semibold'
                            : 'hover:bg-slate-800/40 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          {isCompleted ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-600 shrink-0" />
                          )}
                          <span className="truncate">{lesson.titleAr}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono shrink-0">
                          {lesson.durationMinutes}د
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
