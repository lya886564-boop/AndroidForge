import React, { useState } from 'react';
import { X, Download, Smartphone, CheckCircle2, Copy, ShieldCheck } from 'lucide-react';

interface DownloadApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // The active running development app URL & Public Gofile Download URL
  const gofileDownloadUrl = 'https://gofile.io/d/UwJkFO2A';
  const devAppUrl = 'https://ais-dev-5m2fyckesfu6pxu7wq66ox-700219961654.europe-west2.run.app';
  const directDownloadPageUrl = `${devAppUrl}/download`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(gofileDownloadUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="bg-[#101726] border-2 border-emerald-500/50 rounded-2xl w-full max-w-lg shadow-2xl p-5 sm:p-6 text-slate-100 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>تنزيل ملف التطبيق (APK)</span>
              <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                20 MB
              </span>
            </h2>
            <p className="text-xs text-slate-400">تنزيل مباشر لحزمة تثبيت كود ماستر AI</p>
          </div>
        </div>

        {/* Instructions Banner */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 mb-4 text-xs space-y-1">
          <p className="text-emerald-400 font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>اختر إحدى الطريقتين بالأسفل للتنزيل الفوري:</span>
          </p>
          <p className="text-slate-300 leading-relaxed text-[11px]">
            1. اضغط الزر الأخضر بالأسفل للتنزيل الفوري مباشرة على هاتفك.<br />
            2. أو افتح رابط صفحة التحميل المباشرة في متصفحك.
          </p>
        </div>

        {/* Primary Download Anchor Button */}
        <div className="space-y-3 mb-4">
          <a
            href="/api/download/android-apk"
            download="CodeMasterAI-v1.0.apk"
            className="w-full flex items-center justify-center gap-2.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold text-sm sm:text-base py-4 px-5 rounded-2xl shadow-xl shadow-emerald-600/40 active:scale-[0.98] transition text-center no-underline cursor-pointer"
          >
            <Download className="w-5 h-5 shrink-0" />
            <span>اضغط هنا لتنزيل ملف CodeMasterAI-v1.0.apk (20MB)</span>
          </a>

          {/* Direct Public Download Link Box */}
          <div className="space-y-1.5 pt-1">
            <label className="text-[11px] text-emerald-400 block font-bold">
              رابط التحميل المباشر العام (يعمل على أي هاتف مثل ميديا فاير بدون 403):
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={gofileDownloadUrl}
                className="flex-1 bg-slate-950 border border-emerald-500/40 rounded-lg px-3 py-2 text-xs font-mono text-emerald-400 text-left select-all focus:outline-none"
                dir="ltr"
              />
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-xs font-bold px-3.5 py-2 rounded-lg text-white shrink-0 transition"
              >
                {copied ? <CheckCircle2 className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Specifications */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 text-xs space-y-1.5 text-slate-300">
          <div className="flex justify-between">
            <span className="text-slate-400">اسم الملف:</span>
            <span className="font-mono text-emerald-400 font-bold">CodeMasterAI-v1.0.apk</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">حجم الملف:</span>
            <span className="font-mono text-cyan-400 font-bold">20.00 MB (20,971,520 bytes)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">نظام التشغيل:</span>
            <span className="text-slate-200">أندرويد (جميع الإصدارات)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
