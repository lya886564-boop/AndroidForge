import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  RotateCcw, 
  Save, 
  Terminal, 
  Eye, 
  AlertTriangle, 
  Bot, 
  Check, 
  Copy, 
  FileCode,
  Sparkles
} from 'lucide-react';
import { runHtmlCode, runPythonCode, runSqlCode, ExecutionResult } from '../utils/codeRunner.ts';
import { diagnoseCodeOffline } from '../data/offlineDiagnostics.ts';
import { saveCode, getSavedCode } from '../utils/storage.ts';

interface CodeEditorViewProps {
  initialCode?: string;
  initialLanguage?: string;
  onAskAiAboutError: (code: string, errorMsg: string, lang: string) => void;
}

const TEMPLATES: Record<string, string> = {
  python: `# برنامج بايثون لحساب الأرقام وتحليل القوائم
def calculate_grades(scores):
    average = sum(scores) / len(scores)
    print(f"متوسط الدرجات: {average:.1f}")
    
    for s in scores:
        if s >= 90:
            print(f"درجة متميزة: {s}")

my_scores = [95, 88, 92, 79, 99]
calculate_grades(my_scores)
`,
  html: `<!DOCTYPE html>
<html dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: sans-serif; background: #0b132b; color: white; padding: 20px; text-align: center; }
    h1 { color: #38bdf8; }
    .card { background: #1c2541; padding: 20px; border-radius: 16px; max-width: 350px; margin: 20px auto; }
    button { background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h1>مرحباً بك في كود ماستر AI 🚀</h1>
    <p>هذا تطبيق ويب تفاعلي يعمل بالمعاينة الحية المباشرة.</p>
    <button onclick="alert('تم تشغيل الزر بنجاح!')">اضغط للتجربة</button>
  </div>
</body>
</html>
`,
  kotlin: `// كود كوتلن لأندرويد
fun main() {
    val studentName = "عمر"
    var xpPoints = 320
    
    println("أهلاً بك يا $studentName في محرر أندرويد!")
    println("نقاطك الحالية: $xpPoints XP")
    
    xpPoints += 50
    println("بعد إكمال التحدي: $xpPoints XP 🚀")
}
`,
  sql: `-- استعلام بيانات الطلاب المتفوقين في SQLite
CREATE TABLE learners (
    id INT,
    name TEXT,
    track TEXT,
    xp INT
);

INSERT INTO learners VALUES (1, 'أحمد', 'بايثون', 650);
INSERT INTO learners VALUES (2, 'سارة', 'أندرويد', 780);

SELECT * FROM learners WHERE xp > 700;
`
};

export const CodeEditorView: React.FC<CodeEditorViewProps> = ({
  initialCode,
  initialLanguage = 'python',
  onAskAiAboutError,
}) => {
  const [language, setLanguage] = useState<string>(initialLanguage);
  const [code, setCode] = useState<string>(
    initialCode || getSavedCode('active_project', TEMPLATES[initialLanguage] || TEMPLATES.python)
  );
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);
  const [activeOutputTab, setActiveOutputTab] = useState<'console' | 'preview' | 'diagnostics'>('console');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [offlineDiagnosis, setOfflineDiagnosis] = useState<any>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initialCode) {
      setCode(initialCode);
      if (initialLanguage) setLanguage(initialLanguage);
    }
  }, [initialCode, initialLanguage]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleRunCode = () => {
    let res: ExecutionResult;
    if (language === 'html') {
      res = runHtmlCode(code);
      setActiveOutputTab('preview');
    } else if (language === 'python') {
      res = runPythonCode(code);
      setActiveOutputTab('console');
    } else if (language === 'sql') {
      res = runSqlCode(code);
      setActiveOutputTab('console');
    } else {
      // Kotlin/Java simulation
      res = {
        output: `[محاكي Kotlin أندرويد]:\nتم تجميع الكود بنجاح عبر مترجم كوتلن.\n\nالمخرجات:\n${code.includes('println') ? code.match(/println\(([^)]+)\)/g)?.map(s => s.slice(8, -1)).join('\n') : 'تم تشغيل الكود بنجاح.'}`,
        isError: false,
      };
      setActiveOutputTab('console');
    }

    setExecutionResult(res);

    if (res.isError) {
      const diag = diagnoseCodeOffline(code, res.rawError);
      setOfflineDiagnosis(diag);
      setActiveOutputTab('diagnostics');
    } else {
      setOfflineDiagnosis(null);
    }
  };

  const handleSave = () => {
    saveCode('active_project', code);
    showToast('تم حفظ مشروعك البرمجي بنجاح في الذاكرة المحلية 💾');
  };

  const handleInsertChar = (chars: string) => {
    if (!textareaRef.current) return;
    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const nextCode = code.substring(0, start) + chars + code.substring(end);
    setCode(nextCode);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + chars.length, start + chars.length);
    }, 0);
  };

  const lines = code.split('\n');

  return (
    <div className="pb-24 max-w-6xl mx-auto px-4 pt-2 space-y-3">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-cyan-600 text-white text-xs font-semibold px-4 py-2 rounded-xl shadow-xl flex items-center gap-2 animate-fade-in">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Toolbar */}
      <div className="bg-[#101726] border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
        {/* Language Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">اللغة:</span>
          <select
            value={language}
            onChange={(e) => {
              const lang = e.target.value;
              setLanguage(lang);
              setCode(TEMPLATES[lang] || '');
              setExecutionResult(null);
            }}
            className="bg-slate-900 border border-slate-700 text-slate-200 text-xs font-semibold rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-400"
          >
            <option value="python">Python 🐍</option>
            <option value="html">HTML5 / CSS / JS 🌐</option>
            <option value="kotlin">Kotlin Android 📱</option>
            <option value="sql">SQL & SQLite 🗄️</option>
          </select>

          <button
            onClick={() => setCode(TEMPLATES[language] || '')}
            className="text-xs text-slate-400 hover:text-slate-200 p-1.5 rounded-lg border border-slate-800 hover:bg-slate-800 transition"
            title="إعادة تعيين القالب"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            <Save className="w-3.5 h-3.5 text-cyan-400" />
            <span>حفظ</span>
          </button>

          <button
            onClick={handleRunCode}
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold px-4 py-1.5 rounded-lg shadow-sm shadow-emerald-500/20 active:scale-95 transition"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>تشغيل الكود</span>
          </button>
        </div>
      </div>

      {/* Mobile Special Key Bar (Ergonomics) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none" dir="ltr">
        {[':', '=', '(', ')', '{', '}', '[', ']', '"', "'", '<', '>', '/', '#', 'def ', 'print(', 'class '].map((symbol, idx) => (
          <button
            key={idx}
            onClick={() => handleInsertChar(symbol)}
            className="bg-slate-900 hover:bg-slate-800 active:bg-cyan-500/20 border border-slate-800 text-cyan-300 font-mono text-xs font-bold px-2.5 py-1.5 rounded-lg shrink-0 transition"
          >
            {symbol}
          </button>
        ))}
      </div>

      {/* Editor & Execution Split Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Code Input (lg:col-span-7) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col min-h-[380px]">
          {/* File Tab */}
          <div className="bg-[#0b101c] border-b border-slate-800 px-3 py-2 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-400 font-mono">
              <FileCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>main.{language === 'python' ? 'py' : language === 'html' ? 'html' : language === 'kotlin' ? 'kt' : 'sql'}</span>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">{lines.length} سطر</span>
          </div>

          {/* Editor Body with Gutter Numbers */}
          <div className="relative flex-1 flex text-left font-mono text-xs" dir="ltr">
            {/* Line Numbers Gutter */}
            <div className="w-10 bg-[#070b13] text-slate-600 select-none py-3 px-1 text-right border-r border-slate-800/80 leading-5">
              {lines.map((_, i) => {
                const isErrorLine = executionResult?.errorLine === i + 1;
                return (
                  <div
                    key={i}
                    className={`${isErrorLine ? 'bg-rose-500/30 text-rose-400 font-bold' : ''}`}
                  >
                    {i + 1}
                  </div>
                );
              })}
            </div>

            {/* Code Textarea */}
            <textarea
              ref={textareaRef}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              spellCheck={false}
              className="flex-1 bg-transparent text-slate-200 p-3 leading-5 resize-none focus:outline-none font-mono text-xs overflow-y-auto whitespace-pre selection:bg-cyan-500/30"
              style={{ minHeight: '340px' }}
            />
          </div>
        </div>

        {/* Output & Diagnostics Viewer (lg:col-span-5) */}
        <div className="lg:col-span-5 bg-[#101726] border border-slate-800 rounded-xl overflow-hidden flex flex-col min-h-[380px]">
          {/* Output Header Tabs */}
          <div className="bg-slate-900/80 border-b border-slate-800 p-1 flex items-center gap-1 text-xs">
            <button
              onClick={() => setActiveOutputTab('console')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeOutputTab === 'console'
                  ? 'bg-slate-800 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>المخرجات (Console)</span>
            </button>

            {language === 'html' && (
              <button
                onClick={() => setActiveOutputTab('preview')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                  activeOutputTab === 'preview'
                    ? 'bg-slate-800 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span>المعاينة الحية</span>
              </button>
            )}

            {executionResult?.isError && (
              <button
                onClick={() => setActiveOutputTab('diagnostics')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                  activeOutputTab === 'diagnostics'
                    ? 'bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30'
                    : 'text-rose-400 hover:text-rose-300'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>تشخيص الخطأ</span>
              </button>
            )}
          </div>

          {/* Tab Views */}
          <div className="flex-1 p-3 overflow-y-auto">
            {activeOutputTab === 'console' && (
              <div className="h-full flex flex-col">
                <div
                  className="flex-1 bg-slate-950 border border-slate-800/80 rounded-lg p-3 text-left font-mono text-xs whitespace-pre-wrap overflow-y-auto"
                  dir="ltr"
                >
                  {executionResult ? (
                    <span className={executionResult.isError ? 'text-rose-400' : 'text-emerald-300'}>
                      {executionResult.output}
                    </span>
                  ) : (
                    <span className="text-slate-500 italic">اضغط على زر "تشغيل الكود" لتنفيذ البرنامج ورؤية المخرجات هنا...</span>
                  )}
                </div>
              </div>
            )}

            {activeOutputTab === 'preview' && (
              <div className="h-full min-h-[300px] bg-white rounded-lg overflow-hidden border border-slate-700">
                {executionResult?.renderHtml ? (
                  <iframe
                    title="Live HTML Preview"
                    srcDoc={executionResult.renderHtml}
                    sandbox="allow-scripts allow-modals"
                    className="w-full h-full min-h-[320px] border-none"
                  />
                ) : (
                  <div className="h-full flex items-center justify-center text-xs text-slate-500">
                    اضغط "تشغيل الكود" لتوليد المعاينة الحية.
                  </div>
                )}
              </div>
            )}

            {activeOutputTab === 'diagnostics' && (
              <div className="space-y-3">
                <div className="bg-rose-950/40 border border-rose-800/60 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center gap-2 text-rose-300 font-bold text-xs sm:text-sm">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{offlineDiagnosis?.errorNameAr || 'تم رصد خطأ برمجي'}</span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {offlineDiagnosis?.causeAr || executionResult?.rawError}
                  </p>

                  <div className="bg-slate-900/90 rounded-lg p-2.5 text-xs text-slate-200 border border-slate-800">
                    <span className="text-emerald-400 font-bold">الحل المقترح: </span>
                    <span>{offlineDiagnosis?.suggestionAr}</span>
                  </div>

                  {offlineDiagnosis?.exampleFixAr && (
                    <div className="bg-slate-950 p-2 rounded text-[11px] font-mono text-cyan-300 text-left" dir="ltr">
                      <pre>{offlineDiagnosis.exampleFixAr}</pre>
                    </div>
                  )}
                </div>

                {/* Ask Gemini Tutor Button */}
                <button
                  onClick={() => onAskAiAboutError(code, executionResult?.rawError || 'خطأ في الكود', language)}
                  className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs py-2.5 px-3 rounded-xl shadow-md transition"
                >
                  <Bot className="w-4 h-4" />
                  <span>اسأل المعلم الذكي AI لشرح وحل هذا الخطأ بالتفصيل</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
