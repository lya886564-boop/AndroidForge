# دليل بناء تطبيق Code Master AI عبر AndroidForge

تم إعداد هذا المشروع بالكامل بواسطة المطور: **𝑶𝒔**  
متوافق بنسبة 100% مع منصة **AndroidForge**:
https://professional-x.github.io/AndroidForge/

---

## طرق البناء والتوليد (3 طرق متوفرة):

### الطريقة الأولى: التنزيل المباشر كملف ZIP بضغطة زر داخل التطبيق
- افتح التطبيق واضغط على زر **"تحميل حزمة AndroidForge (ZIP)"** من شريط التنقل أو من صفحة أندرويد.
- يقوم التطبيق فوراً بتوليد وتجميع كافة الملفات (Gradle + Manifest + Kotlin + Web Assets) في ملف أرشيف واحد `CodeMasterAI-AndroidForge.zip`.

### الطريقة الثانية: رابط التنزيل عبر خادم الـ API
- يمكنك تنزيل ملف الـ ZIP مباشرة عبر مسار الخادم:
  `/api/download/androidforge-zip`
- مناسب للاستخدام عبر أدوات التنزيل التلقائية أو عبر المتصفح مباشرة.

### الطريقة الثالثة: الرفع المباشر إلى AndroidForge
1. قم بفك ضغط ملف `CodeMasterAI-AndroidForge.zip` أو رفع الملف كاملاً إلى AndroidForge.
2. حدد مسار الأصول: `app/src/main/assets/www/`
3. اختر نوع التطبيق: **WebView WebApp Native Android**
4. اضغط على زر **"Build APK"** داخل AndroidForge، وسيقوم بتوليد ملف الـ APK النهائي الموقع والجاهز للتثبيت على الهواتف!

---

## متطلبات الحزمة:
- **Package Name**: `com.codemaster.ai`
- **Min SDK**: 24 (Android 7.0 Nougat فما فوق)
- **Target SDK**: 34 (Android 14)
- **Engine**: Chrome WebView with Local HTML5/ES6 Assets
- **المطور والمخصص**: **𝑶𝒔**
