# مشروع Code Master AI المهيأ لـ AndroidForge
### المطور والمسؤول: **𝑶𝒔**
### رقم المطور: **249120591509**
### الرابط المعتمد: [https://professional-x.github.io/AndroidForge/](https://professional-x.github.io/AndroidForge/)

---

## 🛠 طريقة البناء السريعة باستخدام AndroidForge:
1. حمّل ملف الأرشيف المضغوط هذا `CodeMasterAI-AndroidForge.zip`.
2. ادخل إلى منصة [AndroidForge Web Builder](https://professional-x.github.io/AndroidForge/).
3. اختر رفع حزمة المشروع (Upload Project ZIP).
4. اضغط على زر **بناء الحزمة (Build APK)**.
5. ستقوم المنصة ببناء ملف APK موقّع وجاهز للتثبيت على جميع هواتف أندرويد تلقائياً.

---

## 💻 طريقة الفتح والتعديل في Android Studio:
1. فك ضغط ملف `CodeMasterAI-AndroidForge.zip`.
2. افتح **Android Studio**.
3. اختر **Open** ثم اختر المجلد المفكوك.
4. انتظر اكتمال مزامنة Gradle Sync.
5. اضغط على **Run** لتشغيل التطبيق على المحاكي أو جهاز حقيقي.

---
حجم هذا الأرشيف أقل من 500 كيلوبايت، وخالٍ تماماً من أي مسارات محلية، وجاهز للعمل فوراً.
