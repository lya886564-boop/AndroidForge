function runOfflineCode() {
    const code = document.getElementById('code-input').value;
    const output = document.getElementById('output-box');
    
    output.innerText = "جاري تنفيذ الكود...";
    
    setTimeout(() => {
        try {
            if (code.includes('print(') || code.includes('def ')) {
                // Micro Python simulator
                const lines = code.split('\n');
                let prints = [];
                for (let line of lines) {
                    if (line.trim().startsWith('print(')) {
                        let content = line.substring(line.indexOf('(') + 1, line.lastIndexOf(')'));
                        prints.push(content.replace(/['"]/g, ''));
                    }
                }
                output.innerText = prints.length > 0 ? prints.join('\n') : "تم تنفيذ كود بايثون بنجاح دون مخرجات شاشة.";
            } else {
                // JS Execution
                let captured = [];
                const originalLog = console.log;
                console.log = (...args) => captured.push(args.join(' '));
                eval(code);
                console.log = originalLog;
                output.innerText = captured.length > 0 ? captured.join('\n') : "تم تنفيذ كود JavaScript بنجاح.";
            }
            if (window.AndroidBridge && window.AndroidBridge.showToast) {
                window.AndroidBridge.showToast("تم التشغيل بنجاح!");
            }
        } catch (e) {
            output.innerText = "خطأ في التنفيذ: " + e.message;
        }
    }, 200);
}
