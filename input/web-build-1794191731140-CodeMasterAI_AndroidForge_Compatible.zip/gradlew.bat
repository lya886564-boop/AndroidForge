@rem Gradle startup script for Windows
@if "%DEBUG%" == "" @echo off
set CLASSPATH="gradle\wrapper\gradle-wrapper.jar"
java -Xmx64m -Xms64m -Dorg.gradle.appname=gradlew -classpath %CLASSPATH% org.gradle.wrapper.GradleWrapperMain %*
