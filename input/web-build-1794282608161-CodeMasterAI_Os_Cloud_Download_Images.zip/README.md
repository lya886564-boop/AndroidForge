# Code Master AI — Os Edition (Cloud + Native Downloads + Visual Lessons)

## Added in this revision
- Native Android downloads through `DownloadManager`: enter a direct HTTP(S) PDF/ZIP/video URL in the academy and the file is saved to the phone's Downloads folder with a system notification. This does not depend on WebView's download support.
- Cloud API settings: endpoint, model, and password-style API-key field. On Android the key is stored in app-private SharedPreferences and can be retrieved for the app. The app sends it to the configured API endpoint only when the user submits a prompt.
- Offline bundled SVG teaching diagrams for Python flow, variables, functions, loops, conditions, and the programming input/process/output model.
- A starter multi-language reference library with examples.
- Offline lesson pack export as JSON.
- Full-screen code editor and `p` -> `print()` completion suggestion.

## Important security and behavior notes
- The API key is stored in private app preferences, not encrypted with Android Keystore. Do not use a personal production key in a distributed public APK. A backend proxy is safer for a public release.
- The cloud API requires internet, a valid key, and a compatible OpenAI-style Chat Completions endpoint/model. Provider CORS policies may prevent browser-side requests in some configurations.
- External downloads must be direct file URLs accessible without a login or browser-only JavaScript page. Android DownloadManager handles the actual download and saves to `Downloads`.
- Bundled SVG diagrams work offline; no external image download is required.
- Python execution in this starter app is a limited demo, not a complete Python interpreter. The code editor is for editing and learning; real Python execution needs an embedded runtime/server.
- API usage may incur charges from the provider. The user is responsible for their API account and key.
