package com.codemaster.ai;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import org.json.JSONArray;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Code Master AI - Android Hybrid Native WebView Runner
 * Developer: 𝑶𝒔
 * Compatible with AndroidForge: https://professional-x.github.io/AndroidForge/
 */
public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    
    // Offline local asset fallback or remote URL
    private static final String LOCAL_URL = "file:///android_asset/www/index.html";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        // Configure modern WebView settings
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Native JS Interface for bidirectional interaction
        webView.addJavascriptInterface(new WebAppInterface(), "AndroidBridge");

        // Progress Chrome client
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            enqueueDownload(url, contentDisposition, mimeType);
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(newProgress);
                } else {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });

        // WebViewClient to keep browsing within the app
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                // If remote fails, fallback smoothly to local offline asset
                if (!view.getUrl().equals(LOCAL_URL)) {
                    view.loadUrl(LOCAL_URL);
                }
            }
        });

        // Load the bundled offline application
        webView.loadUrl(LOCAL_URL);
    }

    private void enqueueDownload(String url, String fileName, String mimeType) {
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) && !"http".equalsIgnoreCase(uri.getScheme())) {
                Toast.makeText(this, "رابط التنزيل غير صالح", Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setTitle(fileName == null || fileName.isEmpty() ? "Code Master AI - تنزيل درس" : fileName);
            request.setDescription("يتم حفظ الملف في مجلد Downloads");
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    fileName == null || fileName.isEmpty() ? "CodeMaster_download" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_"));
            if (mimeType != null && !mimeType.isEmpty()) request.setMimeType(mimeType);
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "بدأ التنزيل — ستجد الملف في Downloads", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر بدء التنزيل: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public class WebAppInterface {
        @JavascriptInterface
        public void showToast(String message) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        }

        @JavascriptInterface
        public String getDeveloperInfo() {
            return "𝑶𝒔";
        }

        @JavascriptInterface
        public void downloadFile(String url, String fileName) {
            runOnUiThread(() -> enqueueDownload(url, fileName, null));
        }

        @JavascriptInterface
        public void saveApiKey(String key) {
            getSharedPreferences("cloud_settings", MODE_PRIVATE).edit().putString("api_key", key == null ? "" : key.trim()).apply();
        }

        @JavascriptInterface
        public String getApiKey() {
            return getSharedPreferences("cloud_settings", MODE_PRIVATE).getString("api_key", "");
        }

        @JavascriptInterface
        public String chatCloud(String prompt, String code) {
            HttpURLConnection connection = null;
            try {
                SharedPreferences prefs = getSharedPreferences("cloud_settings", MODE_PRIVATE);
                String key = prefs.getString("api_key", "");
                String endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions");
                String model = prefs.getString("model", "gpt-4o-mini");
                if (key.isEmpty()) return "{\\"error\\":{\\"message\\":\\"أدخل مفتاح API أولًا\\"}}";
                JSONObject user = new JSONObject();
                user.put("role", "user");
                user.put("content", prompt + "\\n\\nالكود الحالي:\\n" + (code == null ? "" : code));
                JSONObject system = new JSONObject();
                system.put("role", "system");
                system.put("content", "أنت مدرس برمجة خبير. أجب بالعربية واشرح الأخطاء مع كود صحيح.");
                JSONArray messages = new JSONArray();
                messages.put(system);
                messages.put(user);
                JSONObject body = new JSONObject();
                body.put("model", model);
                body.put("messages", messages);
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(60000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setRequestProperty("Authorization", "Bearer " + key);
                byte[] payload = body.toString().getBytes("UTF-8");
                connection.getOutputStream().write(payload);
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();
                return response.toString();
            } catch (Exception e) {
                JSONObject error = new JSONObject();
                JSONObject detail = new JSONObject();
                try { detail.put("message", e.getMessage() == null ? "فشل الاتصال" : e.getMessage()); error.put("error", detail); }
                catch (Exception ignored) {}
                return error.toString();
            } finally {
                if (connection != null) connection.disconnect();
            }
        }

        @JavascriptInterface
        public void saveCloudConfig(String endpoint, String model) {
            SharedPreferences p = getSharedPreferences("cloud_settings", MODE_PRIVATE);
            p.edit().putString("endpoint", endpoint == null ? "" : endpoint.trim())
                .putString("model", model == null ? "" : model.trim()).apply();
        }

        @JavascriptInterface
        public String getCloudConfig() {
            SharedPreferences p = getSharedPreferences("cloud_settings", MODE_PRIVATE);
            return p.getString("endpoint", "https://api.openai.com/v1/chat/completions") + "\\n" +
                   p.getString("model", "gpt-4o-mini");
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("handleAndroidBack ? handleAndroidBack() : false", value -> {
                if ("true".equals(value)) return;
                if (webView.canGoBack()) webView.goBack();
                else MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }
}
