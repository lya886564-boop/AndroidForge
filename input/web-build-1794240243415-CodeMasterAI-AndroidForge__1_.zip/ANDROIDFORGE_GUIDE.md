# دليل تشغيل وبناء مشروع Code Master AI على AndroidForge
1. ارفع ملف ZIP إلى منصة https://professional-x.github.io/AndroidForge/
2. اضغط على استيراد المشروع (Import Project)
3. تأكد من تحديد Package Name: com.codemaster.ai
4. اضغط على زر Build APK
