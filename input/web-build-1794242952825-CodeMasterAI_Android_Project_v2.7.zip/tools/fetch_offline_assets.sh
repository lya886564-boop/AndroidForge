#!/usr/bin/env bash
# تنزيل موارد العمل دون إنترنت (Pyodide + الخطوط) إلى assets قبل البناء.
# الاستخدام: tools/fetch_offline_assets.sh [core|full]
#   core: مشغّل Python الأساسي فقط (أخف)      full: Pyodide كاملاً مع numpy وpandas وmatplotlib... (أثقل بكثير)
set -euo pipefail
MODE="${1:-core}"
PYODIDE_VERSION="0.25.1"   # يجب أن يطابق الإصدار في AssetRouter.kt وحزمة الواجهة
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/android/app/src/main/assets"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$ASSETS/pyodide" "$ASSETS/fonts"

echo "==> Pyodide $PYODIDE_VERSION ($MODE)"
curl -fL --retry 3 -o "$TMP/pyodide.tar.bz2" \
  "https://github.com/pyodide/pyodide/releases/download/${PYODIDE_VERSION}/pyodide-${PYODIDE_VERSION}.tar.bz2"
tar -xjf "$TMP/pyodide.tar.bz2" -C "$TMP"
if [ "$MODE" = "full" ]; then
  cp -r "$TMP/pyodide/." "$ASSETS/pyodide/"
else
  for f in pyodide.js pyodide.asm.js pyodide.asm.wasm python_stdlib.zip pyodide-lock.json; do
    cp "$TMP/pyodide/$f" "$ASSETS/pyodide/$f"
  done
fi
for must in pyodide.js pyodide.asm.wasm python_stdlib.zip pyodide-lock.json; do
  test -s "$ASSETS/pyodide/$must" || { echo "ERROR: missing $must"; exit 1; }
done

echo "==> Fonts (اختياري؛ الفشل لا يوقف البناء)"
( cd "$TMP" && npm pack @fontsource/tajawal@5 @fontsource/fira-code@5 >/dev/null \
  && for t in fontsource-*.tgz; do mkdir -p "x_$t" && tar -xzf "$t" -C "x_$t"; done \
  && for w in 400 500 700 800 900; do cp x_*/package/files/tajawal-arabic-$w-normal.woff2 "$ASSETS/fonts/" ; done \
  && for w in 400 500 600 700; do cp x_*/package/files/fira-code-latin-$w-normal.woff2 "$ASSETS/fonts/"; done ) \
  || echo "WARN: تعذّر تنزيل الخطوط، سيُستخدم خط النظام"

du -sh "$ASSETS/pyodide" "$ASSETS/fonts" || true
