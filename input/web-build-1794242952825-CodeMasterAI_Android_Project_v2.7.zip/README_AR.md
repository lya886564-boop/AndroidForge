# Code Master AI — مشروع Android

**المطوّر: Osama**

## الحالة الحالية (بصدق)
- **لم يُبنَ APK ولم يُختبر على جهاز** في بيئة إعداد هذه الحزمة (لا إنترنت ولا Android SDK). لا تعتبر المشروع جاهزاً قبل نجاح workflow وتجربة APK على هاتف حقيقي.
- واجهة التطبيق (React) موجودة هنا **كحزمة JavaScript مضغوطة فقط** (`assets/assets/index-*.js`) بلا الكود المصدري. لذلك لا يمكن تعديل الواجهة أو إضافة دورات وشاشات جديدة قبل توفير مصدر الواجهة (مجلد `src` ومعه `package.json`).

## ما أُصلح في هذه النسخة
1. **انهيار عند الفتح:** الثيم كان غير متوافق مع `AppCompatActivity`؛ صار `Theme.AppCompat.DayNight.NoActionBar`.
2. **فشل بناء Gradle:** تعارض `allprojects { repositories }` مع `FAIL_ON_PROJECT_REPOS`؛ حُذف.
3. المانيفست: إزالة `package` المكرر مع `namespace`، وأذونات التخزين غير اللازمة.
4. تضارب رقم الإصدار (2.5.0 / 2.6.0) وُحّد إلى 2.7.0.
5. **Python دون إنترنت:** واجهة الويب تحمّل Pyodide من CDN؛ الآن `AssetRouter` يحوّل هذه الطلبات إلى ملفات محلية في `assets/pyodide/` (تُنزَّل عند البناء).
6. **خطوط محلية** بدل Google Fonts.
7. WebView: اختيار الملفات، فتح الروابط الخارجية في المتصفح، زر الرجوع الحديث، تفعيل التصحيح في نسخة debug فقط.
8. اختبارات وحدة (`AssetRouterTest`) تعمل ضمن GitHub Actions.

## البناء عبر GitHub Actions
1. ارفع محتويات المجلد إلى مستودع GitHub.
2. Actions ← **Build Code Master AI APK** ← Run workflow، واختر `core` (أخف) أو `full` (Pyodide كاملاً مع numpy/pandas/matplotlib، وهو كبير جداً).
3. نزّل artifact `CodeMasterAI-debug-apk` وثبّت `app-debug.apk`.
4. إن فشل أي خطوة فأرسل لي السجل وأصلحه.

## البناء محلياً
```
tools/fetch_offline_assets.sh core
cd android && gradle wrapper --gradle-version 8.2 && ./gradlew testDebugUnitTest assembleDebug
```

## الحجم (600MB)
لم أضف حشواً. الحجم الحقيقي يأتي من Pyodide الكامل (مئات الميغابايت)، ويمكن إضافة محتوى دورات حقيقي لاحقاً. مساعد الذكاء الاصطناعي داخل الواجهة لم أتحقق من آلية عمله لغياب المصدر.
