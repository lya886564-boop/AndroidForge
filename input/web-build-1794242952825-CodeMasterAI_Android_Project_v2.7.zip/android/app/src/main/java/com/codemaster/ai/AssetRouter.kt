package com.codemaster.ai

import java.net.URI

/**
 * يحوّل طلبات CDN التي تستخدمها واجهة الويب (Pyodide) إلى ملفات محلية داخل assets،
 * فيعمل مشغّل Python دون إنترنت. لا يعتمد على android.* ليسهل اختباره.
 */
object AssetRouter {
    data class Local(val assetPath: String, val mimeType: String)

    private const val PYODIDE_HOST = "cdn.jsdelivr.net"
    private const val PYODIDE_PREFIX = "/pyodide/v0.25.1/full/"

    fun resolve(url: String): Local? {
        val uri = try { URI(url) } catch (e: Exception) { return null }
        val host = uri.host?.lowercase() ?: return null
        val path = uri.path ?: return null
        if (host != PYODIDE_HOST || !path.startsWith(PYODIDE_PREFIX)) return null
        val rel = path.removePrefix(PYODIDE_PREFIX)
        if (rel.isEmpty() || rel.contains("..") || rel.startsWith("/")) return null
        return Local("pyodide/$rel", mimeFor(rel))
    }

    fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "wasm" -> "application/wasm"
        "js", "mjs" -> "text/javascript"
        "json" -> "application/json"
        "zip", "whl" -> "application/zip"
        "css" -> "text/css"
        "html" -> "text/html"
        else -> "application/octet-stream"
    }
}
