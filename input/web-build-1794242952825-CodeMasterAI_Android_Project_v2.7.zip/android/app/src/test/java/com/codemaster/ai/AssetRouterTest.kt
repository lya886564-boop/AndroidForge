package com.codemaster.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AssetRouterTest {
    @Test fun pyodideWasmIsRoutedLocally() {
        val r = AssetRouter.resolve("https://cdn.jsdelivr.net/pyodide/v0.25.1/full/pyodide.asm.wasm")
        assertNotNull(r)
        assertEquals("pyodide/pyodide.asm.wasm", r!!.assetPath)
        assertEquals("application/wasm", r.mimeType)
    }

    @Test fun queryStringIsIgnored() {
        val r = AssetRouter.resolve("https://cdn.jsdelivr.net/pyodide/v0.25.1/full/pyodide-lock.json?x=1")
        assertEquals("pyodide/pyodide-lock.json", r!!.assetPath)
        assertEquals("application/json", r.mimeType)
    }

    @Test fun otherHostsAndVersionsAreNotRouted() {
        assertNull(AssetRouter.resolve("https://example.com/pyodide/v0.25.1/full/pyodide.js"))
        assertNull(AssetRouter.resolve("https://cdn.jsdelivr.net/pyodide/v0.26.0/full/pyodide.js"))
        assertNull(AssetRouter.resolve("https://appassets.androidplatform.net/assets/index.html"))
    }

    @Test fun pathTraversalAndBadUrlsAreRejected() {
        assertNull(AssetRouter.resolve("https://cdn.jsdelivr.net/pyodide/v0.25.1/full/../secret"))
        assertNull(AssetRouter.resolve("https://cdn.jsdelivr.net/pyodide/v0.25.1/full/"))
        assertNull(AssetRouter.resolve("not a url"))
    }

    @Test fun mimeTypes() {
        assertEquals("text/javascript", AssetRouter.mimeFor("pyodide.js"))
        assertEquals("application/zip", AssetRouter.mimeFor("numpy-1.26.4.whl"))
        assertEquals("application/octet-stream", AssetRouter.mimeFor("noext"))
    }
}
