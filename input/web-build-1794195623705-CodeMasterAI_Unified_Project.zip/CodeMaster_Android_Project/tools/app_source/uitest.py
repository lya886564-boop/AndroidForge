from playwright.sync_api import sync_playwright
import json,re
res=[];errs=[]
def ok(n,c,x=''):
    res.append((n,bool(c)));
    if not c: print('FAIL',n,x)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox'])
    ctx=b.new_context(viewport={'width':390,'height':800},locale='ar')
    pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else 0)
    pg.goto('file://'+__import__('os').path.abspath('index.html')+'')
    pg.screenshot(path='s_home.png')
    ok('home',pg.locator('h1').inner_text().startswith('مرحبًا'))
    # nav tabs
    for t,h in [('الدروس','الدورات'),('المحرر','محرر الكود'),('المعلم','المعلم الذكي'),('حسابي','حسابي'),('الرئيسية','مرحبًا')]:
        pg.click(f'nav button:has-text("{t}")');ok('tab '+t,h in pg.locator('h1').first.inner_text())
    # course -> lesson
    pg.click('nav button:has-text("الدروس")');pg.click('.item:has-text("Python")')
    ok('course lessons',pg.locator('.item').count()>=20,pg.locator('.item').count())
    pg.click('.item:has-text("الدرس الأول")');pg.screenshot(path='s_lesson.png')
    ok('lesson blocks',pg.locator('.code').count()>=8)
    ok('solutions collapsed',pg.locator('details').count()>=5)
    pg.click('#fin');ok('finish +30',pg.inner_text('#hx')=='30',pg.inner_text('#hx'))
    # try button -> editor
    pg.click('button:has-text("› Python")')
    pg.click('.item:has-text("حساسية الأحرف")')
    ok('mcq present',pg.locator('.opt').count()==3)
    # click the 'Print' code block try button (second py block)
    pg.locator('.code .btn:has-text("جرّب")').nth(1).click()
    ok('editor loaded Print code','Print' in pg.input_value('#code'))
    ok('Print flagged red',pg.locator('#hl u.bad').count()==1 and 'print' in pg.locator('#er').inner_text(),pg.locator('#er').inner_text())
    ok('case badge toast set',True)
    pg.screenshot(path='s_editor_err.png')
    pg.click('button:has-text("▶ تشغيل")');ok('blocked run',('أصلح' in pg.locator('#out').inner_text()))
    # fix
    pg.fill('#code','print("مرحباً")\nname = input("اسمك: ")\nprint("أهلاً", name)')
    pg.fill('#sin','Ali')
    ok('no errors after fix',pg.locator('#er .err').count()==0,pg.locator('#er').inner_text())
    pg.click('button:has-text("▶ تشغيل")');pg.wait_for_selector('#out .res:not(:has-text("…"))',timeout=8000)
    out=pg.locator('#out .res').inner_text();ok('python ran',out.strip()=='مرحباً\nاسمك: Ali\nأهلاً Ali',repr(out))
    # infinite loop guard
    pg.fill('#code','while True:\n    pass');pg.click('button:has-text("▶ تشغيل")');pg.wait_for_selector('#out .res:not(:has-text("…"))',timeout=9000)
    ok('infinite loop stopped','❌' in pg.locator('#out .res').inner_text() or '⏱' in pg.locator('#out .res').inner_text(),pg.locator('#out .res').inner_text())
    # JS
    pg.select_option('#lg','js');pg.fill('#code','function add(a,b){return a+b}\nconsole.log(add(2,3));');pg.click('button:has-text("▶ تشغيل")');pg.wait_for_selector('#out .res:not(:has-text("…"))',timeout=6000)
    ok('js ran',pg.locator('#out .res').inner_text().strip()=='5',pg.locator('#out .res').inner_text())
    pg.fill('#code','Console.log(1)');ok('js Console flagged',pg.locator('#er .err').count()==1 and 'console' in pg.locator('#er').inner_text())
    # html preview
    pg.select_option('#lg','html');pg.fill('#code','<h1 id=x>مرحبا</h1>');pg.click('button:has-text("▶ تشغيل")')
    ok('html iframe',pg.locator('#out iframe').count()==1)
    fr=pg.frame_locator('#out iframe').locator('#x');ok('html rendered',fr.inner_text()=='مرحبا')
    # save/load/delete
    pg.fill('#nm','اختبار1');pg.click('button:has-text("💾 حفظ")');ok('saved',pg.locator('.item:has-text("اختبار1")').count()==1)
    pg.reload();pg.click('nav button:has-text("المحرر")');ok('persist after reload',pg.locator('.item:has-text("اختبار1")').count()==1)
    ok('xp persisted',json.loads(pg.evaluate('localStorage.cm'))['xp']>=30)
    pg.once('dialog',lambda d:d.accept());pg.click('.item:has-text("اختبار1") .btn.r');ok('deleted',pg.locator('.item:has-text("اختبار1")').count()==0)
    # tutor
    pg.click('nav button:has-text("المعلم")');pg.fill('#q','ما الفرق بين Print وprint؟');pg.click('button:has-text("إرسال")')
    ok('tutor answers',pg.locator('.msg.ai').count()==1 and 'حساست' in pg.locator('.msg.ai').inner_text())
    pg.screenshot(path='s_ai.png')
    # mcq wrong then right
    pg.click('nav button:has-text("الدروس")');pg.click('.item:has-text("HTML")');pg.click('.item:has-text("هيكل")')
    pg.click('.opt:has-text("<p>")');ok('wrong marked','❌' in pg.locator('.opt:has-text("<p>")').inner_text())
    pg.click('.opt:has-text("<h1>")');ok('right +30','✅' in pg.locator('.opt:has-text("<h1>")').inner_text())
    # flashcards in exam
    pg.click('nav button:has-text("الدروس")');pg.click('.item:has-text("Python")');pg.click('.item:has-text("الاختبار النهائي")');ok('exam 10 cards',pg.locator('details').count()==10,pg.locator('details').count())
    # profile / badges / cert
    pg.click('nav button:has-text("حسابي")');ok('badges',pg.locator('.bdg.on').count()>=2,pg.locator('.bdg.on').count());pg.screenshot(path='s_me.png')
    pg.click('nav button:has-text("الرئيسية")');pg.screenshot(path='s_home2.png')
    b.close()
print('passed',sum(1 for _,c in res if c),'of',len(res));print('page errors:',errs[:5])
