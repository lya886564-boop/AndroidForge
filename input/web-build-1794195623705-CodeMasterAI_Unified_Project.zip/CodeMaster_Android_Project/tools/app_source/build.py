import json
t=open('template.html',encoding='utf-8').read()
core=open('core.js',encoding='utf-8').read()
data=open('data.json',encoding='utf-8').read().replace('</','<\\/')
core=core.replace("if(typeof module!='undefined')module.exports={tok,hl,checkCode,py2js,buildPy,RT};","")
out=t.replace('//@@CORE@@',core).replace('//@@DATA@@',data)
open('index.html','w',encoding='utf-8').write(out)
print(len(out.encode()),'bytes')
