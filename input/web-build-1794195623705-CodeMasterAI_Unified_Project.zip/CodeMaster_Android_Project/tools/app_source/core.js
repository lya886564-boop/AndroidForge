const PYK='False None True and as assert break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield'.split(' ');
const PYB='print input int str float len range type list dict set tuple bool abs round sum min max sorted open enumerate zip map filter isinstance reversed'.split(' ');
const JSK='break case catch class const continue default else export extends false finally for function if import in instanceof let new null return super switch this throw true try typeof undefined var while async await of'.split(' ');
const JSB='console document window alert Math JSON Array Object String Number Date Promise parseInt parseFloat setTimeout'.split(' ');
const SQK='select from where insert into values update set delete create table drop alter join inner left right on group by order having limit as and or not null primary key integer text real distinct count sum avg min max like in between'.split(' ');
const RX={
py:/(#[^\n]*)|([fFrRbB]{0,2}(?:"""[\s\S]*?(?:"""|$)|'''[\s\S]*?(?:'''|$)|"(?:\\.|[^"\\\n])*(?:"|$)|'(?:\\.|[^'\\\n])*(?:'|$)))|(\d+\.?\d*)|([A-Za-z_\u0600-\u06FF][\w\u0600-\u06FF]*)|([\s\S])/g,
sql:/(--[^\n]*)|('(?:[^'\n]|'')*(?:'|$))|(\d+\.?\d*)|([A-Za-z_]\w*)|([\s\S])/g,
js:/(\/\/[^\n]*|\/\*[\s\S]*?(?:\*\/|$))|("(?:\\.|[^"\\\n])*(?:"|$)|'(?:\\.|[^'\\\n])*(?:'|$)|`(?:\\.|[^`\\])*(?:`|$))|(\d+\.?\d*)|([A-Za-z_$][\w$]*)|([\s\S])/g};
function tok(code,lang){const re=new RegExp((RX[lang]||RX.js).source,'g'),T=[];let m;
 while((m=re.exec(code))){const t=m[1]!=null?'c':m[2]!=null?'s':m[3]!=null?'n':m[4]!=null?'w':'o';T.push({t,v:m[0],i:m.index});if(m[0]==='')re.lastIndex++}return T}
const E_=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
function hl(code,lang,bad){bad=bad||[];
 if(lang=='html'||lang=='sh'&&0){return code.replace(/(<!--[\s\S]*?(?:-->|$))|(<\/?[A-Za-z][^>]*>?)|([^<]+|<)/g,(a,c,tg,tx)=>{
  if(c)return'<i class=c>'+E_(c)+'</i>';if(tx)return E_(tx);
  return E_(tg).replace(/^(&lt;\/?)([\w-]+)/,'$1<i class=k>$2</i>').replace(/(\s)([\w:@-]+)(=)/g,'$1<i class=n>$2</i>$3').replace(/("[^"]*"|'[^']*')/g,'<i class=s>$1</i>')})}
 if(lang=='sh')return E_(code);
 const KW=lang=='py'?PYK:lang=='sql'?SQK:JSK,T=tok(code,lang),B=new Set(bad.map(b=>b.s));let o='';
 T.forEach((k,j)=>{let h=E_(k.v),c='';
  if(k.t=='c')c='c';else if(k.t=='s')c='s';else if(k.t=='n')c='n';
  else if(k.t=='w'){const w=lang=='sql'?k.v.toLowerCase():k.v;if(KW.includes(w))c='k';else{let n=j+1;while(T[n]&&T[n].v==' ')n++;
   const p=code[k.i-1];if(T[n]&&T[n].v=='('&&lang!='sql')c=(lang=='py'?PYB:JSB).includes(k.v)?'b':'f';else if(lang=='py'&&PYB.includes(k.v))c='b';else if(lang!='py'&&JSB.includes(k.v))c='b'}}
  if(c)h='<i class='+c+'>'+h+'</i>';if(B.has(k.i))h='<u class=bad>'+h+'</u>';o+=h});return o}
function lnOf(code,i){let n=1;for(let k=0;k<i&&k<code.length;k++)if(code[k]=='\n')n++;return n}
function checkCode(code,lang){const E=[];
 const add=(s,l,msg,ln)=>E.push({ln:ln||lnOf(code,s),s,l,msg});
 if(!code.trim())return E;
 if(lang=='html'){chkHtml(code,add);return E}
 const T=tok(code,lang);const def=new Set();
 if(lang=='py'){
  code.replace(/^[ \t]*(?:def|class)\s+(\w+)/gm,(_,n)=>def.add(n));
  code.replace(/^[ \t]*def\s+\w+\(([^)]*)\)/gm,(_,p)=>p.split(',').forEach(a=>{const n=a.split('=')[0].trim().replace(/^\*+/,'');if(n)def.add(n)}));
  code.replace(/^[ \t]*([A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)*)\s*(?:[-+*\/%]?=)(?!=)/gm,(_,n)=>n.split(',').forEach(x=>def.add(x.trim())));
  code.replace(/\bfor\s+([\w\s,]+?)\s+in\b/g,(_,n)=>n.split(',').forEach(x=>def.add(x.trim())));
  code.replace(/\b(?:import|from)\b.*$/gm,l=>l.replace(/\w+/g,w=>(def.add(w),w)));
  code.replace(/\bas\s+(\w+)/g,(_,n)=>def.add(n));
 }else if(lang=='js'){
  code.replace(/\b(?:const|let|var|function|class)\s+([A-Za-z_$][\w$]*)/g,(_,n)=>def.add(n));
  code.replace(/\(([^()]*)\)\s*(?:=>|\{)/g,(_,p)=>p.split(',').forEach(a=>{const n=a.trim().split('=')[0].trim();if(/^[\w$]+$/.test(n))def.add(n)}));
 }
 const K=lang=='py'?PYK.concat(PYB):lang=='js'?JSK.concat(JSB):[];
 if(K.length)T.forEach(k=>{if(k.t!='w'||code[k.i-1]=='.'||K.includes(k.v)||def.has(k.v))return;
  const lo=k.v.toLowerCase(),hit=K.find(x=>x.toLowerCase()==lo)||[...def].find(x=>x.toLowerCase()==lo);
  if(hit)add(k.i,k.v.length,'«'+k.v+'» غير صحيحة: '+(lang=='py'?'بايثون':'اللغة')+' حساسة لحالة الأحرف (Print ≠ print). الصحيح: «'+hit+'»')});
 if(lang=='sql'){}
 T.forEach(k=>{if(k.t!='s'||lang=='sql')return;const pl=(k.v.match(/^[fFrRbB]*/)||[''])[0].length,b=k.v.slice(pl),q=b[0];if(q=='`')return;
  const ok=b.startsWith(q+q+q)?(b.length>=6&&b.endsWith(q+q+q)):(b.length>=2&&b.endsWith(q)&&!/\\$/.test(b.slice(0,-1)));
  if(!ok)add(k.i,k.v.length,'نص غير مغلق: ناقصة علامة اقتباس '+q)});
 const st=[],pr={')':'(',']':'[','}':'{'},depth=[0];let d=0;
 T.forEach(k=>{if(k.t!='o')return;const ch=k.v;if(ch=='\n'){depth.push(st.length);return}
  if('([{'.includes(ch))st.push(k);else if(pr[ch]){const t=st.pop();if(!t||t.v!=pr[ch])add(k.i,1,'قوس إغلاق «'+ch+'» لا يطابق قوس فتح')}});
 st.forEach(k=>add(k.i,1,'قوس «'+k.v+'» لم يُغلق'));
 if(lang=='py'){const clean=T.map(k=>k.t=='s'?'""':k.t=='c'?'':k.v).join(''),L=clean.split('\n'),raw=code.split('\n');let off=0,prev=null;
  L.forEach((l,i)=>{const start=off;off+=raw[i].length+1;if(!l.trim())return;const ind=l.match(/^[ \t]*/)[0].replace(/\t/g,'    ').length,dp=depth[i]||0;
   if(prev&&prev.hdr&&dp==0&&ind<=prev.ind&&!E.some(e=>e.ln==i+1))add(start,Math.max(1,raw[i].trim().length),'مسافة بادئة مفقودة: الكتلة بعد «:» يجب أن تكون مزاحة إلى الداخل (4 مسافات)',i+1);
   if(dp==0){if(/^\s*(if|elif|else|for|while|def|class|try|except|finally|with)\b/.test(l)&&!l.includes(':'))add(start,raw[i].trim().length,'ناقص «:» في نهاية السطر',i+1);
    if(/^\s*(if|elif|while)\s[^:]*?(?<![=!<>:])=(?!=)/.test(l))add(start,raw[i].trim().length,'استخدم «==» للمقارنة، فالعلامة «=» للإسناد فقط',i+1)}
   prev={hdr:dp==0&&/:\s*$/.test(l),ind}})}
 if(lang=='js'&&!E.length){try{new Function(code)}catch(x){add(0,0,'خطأ في بناء الجملة: '+jsErrAr(x.message),0)}}
 return E}
function jsErrAr(m){return m.replace('Unexpected end of input','انتهى الكود قبل إغلاق قوس أو كتلة').replace(/Unexpected identifier.*/,'اسم غير متوقع (ربما نسيت فاصلة أو عملية)').replace(/Unexpected token.*/,'رمز غير متوقع').replace('Invalid or unexpected token','رمز غير صالح').replace(/(\S+) is not defined/,'«$1» غير معرّف')}
function chkHtml(code,add){const st=[],V='area base br col embed hr img input link meta param source track wbr !doctype'.split(' '),SOFT='li p td th tr option dt dd body html head'.split(' '),re=/<!--[\s\S]*?-->|<(\/?)([A-Za-z!][\w-]*)([^>]*?)(\/?)>/g;let m;
 code=code.replace(/<(script|style)[^>]*>[\s\S]*?<\/\1>/gi,x=>x.replace(/[^\n<>\/a-z]/gi,' ').replace(/[<>]/g,' '));
 while((m=re.exec(code))){if(!m[2])continue;const n=m[2].toLowerCase();if(V.includes(n)||m[4])continue;
  if(!m[1])st.push({n,s:m.index,l:m[0].length});else{const k=st.map(x=>x.n).lastIndexOf(n);
   if(k<0)add(m.index,m[0].length,'وسم إغلاق «</'+n+'>» بلا وسم فتح');else{while(st.length>k+1){const u=st.pop();if(!SOFT.includes(u.n))add(u.s,u.l,'الوسم «<'+u.n+'>» لم يُغلق')}st.pop()}}}
 st.forEach(u=>{if(!SOFT.includes(u.n))add(u.s,u.l,'الوسم «<'+u.n+'>» لم يُغلق')});
 }
function py2js(code){const T=tok(code,'py'),S=[];let txt='';
 T.forEach(k=>{if(k.t=='c')return;if(k.t!='s'){txt+=k.v;return}
  const pl=(k.v.match(/^[fFrRbB]*/)||[''])[0],f=/f/i.test(pl);let b=k.v.slice(pl.length),tri=/^("""|''')/.test(b);
  let body=tri?b.slice(3,-3):b.slice(1,-1),q=b[0],r;
  if(f){body=body.replace(/`/g,'\\`').replace(/\$\{/g,'\\${').replace(/\{([^{}]+)\}/g,(a,e)=>{const m=e.match(/^(.*?):\.(\d+)f$/);return m?'${__f('+m[1]+','+m[2]+')}':'${__s('+e+')}'});r='`'+body+'`'}
  else if(tri){r='`'+body.replace(/`/g,'\\`').replace(/\$\{/g,'\\${')+'`'}else r=b;
  S.push(r);txt+='\u0001'+(S.length-1)+'\u0001'});
 const lines=txt.split('\n').map((l,i)=>({n:i+1,ind:l.match(/^[ \t]*/)[0].replace(/\t/g,'    ').length,t:l.trim()})).filter(l=>l.t);
 const un=x=>x.replace(/\u0001(\d+)\u0001/g,(_,i)=>S[+i]);
 const topColon=t=>{let d=0;for(let i=0;i<t.length;i++){const c=t[i];if('([{'.includes(c))d++;else if(')]}'.includes(c))d--;else if(c==':'&&d==0)return i}return -1};
 const A='((?:[\\w.\\u0001]+(?:\\[[^\\]]*\\])*)|\\[[^\\]]*\\])';
 const ex=e=>{e=e.trim();
  e=e.replace(/\bis\s+not\b/g,'!==').replace(/\bis\b/g,'===')
   .replace(new RegExp(A+'\\s+not\\s+in\\s+'+A,'g'),'!__in($1,$2)').replace(new RegExp(A+'\\s+in\\s+'+A,'g'),'__in($1,$2)')
   .replace(/\bTrue\b/g,'true').replace(/\bFalse\b/g,'false').replace(/\bNone\b/g,'null').replace(/\band\b/g,'&&').replace(/\bor\b/g,'||').replace(/\bnot\b/g,'!');
  const O='(\\w+(?:\\.\\w+)*(?:\\[[^\\]]*\\])?(?:\\([^()]*\\))?|\\([^()]*\\))';
  e=e.replace(new RegExp(O+'\\s*\\/\\/\\s*'+O,'g'),'Math.floor($1 / $2)');
  e=e.replace(/(\w+(?:\[[^\]]*\])?)\.items\(\)/g,'Object.entries($1)').replace(/(\w+(?:\[[^\]]*\])?)\.keys\(\)/g,'Object.keys($1)').replace(/(\w+(?:\[[^\]]*\])?)\.values\(\)/g,'Object.values($1)').replace(/(\w+(?:\[[^\]]*\])?)\.get\(/g,'__get($1,');
  e=e.replace(/(\w+)\[\s*([^\[\]:]*?)\s*:\s*([^\[\]:]*?)\s*\]/g,(a,v,x,y)=>'__sl('+v+','+(x||'undefined')+','+(y||'undefined')+')').replace(/(\w+)\[(-\d+)\]/g,'__at($1,$2)');
  e=e.replace(/\b(sep|end)\s*=\s*(\u0001\d+\u0001|[\w]+)/g,'{__kw:"$1",v:$2}');
  e=e.replace(/(^|[^=!<>])=\s*\(([^()]*,[^()]*)\)\s*$/,'$1= [$2]');if(/^\([^()]*,[^()]*\)$/.test(e))e='['+e.slice(1,-1)+']';return e};
 const out=[],stk=[],cat={};
 const fail=(l,m)=>{throw new Error('السطر '+l.n+': '+m)};
 const END='else { throw __e; } }';
 lines.concat([{n:0,ind:-1,t:'__end__'}]).forEach(l=>{let t=l.t,pre='',cont=/^(elif|else|except|finally)\b/.test(t);
  while(stk.length&&stk[stk.length-1]>=l.ind){const top=stk.pop();if(top==l.ind&&cont&&!pre){pre='} '}else out.push('}')}
  Object.keys(cat).map(Number).sort((x,y)=>y-x).forEach(k=>{if(k>l.ind||(k==l.ind&&!/^(except|finally)\b/.test(t))){out.push(END);delete cat[k]}});
  if(t=='__end__')return;
  if(/^(class|with|lambda|async|await|yield)\b/.test(t))fail(l,'«'+t.split(/\W/)[0]+'» غير مدعومة في المشغّل المبسّط (تعمل في بايثون الحقيقية على Termux)');
  if(/^(global|nonlocal|del)\b/.test(t)){out.push(';');return}
  let m;
  if(/^(import|from)\b/.test(t)){const w=(t.match(/^(?:import|from)\s+(\w+)/)||[])[1];if(!['random','math','json','time'].includes(w))fail(l,'المكتبة «'+w+'» غير متاحة في المشغّل المبسّط');out.push(';');return}
  const isH=/^(if|elif|else|while|for|def|try|except|finally)\b/.test(t);
  if(isH){const c=topColon(t);if(c<0)fail(l,'ناقص «:» في نهاية السطر');let head=t.slice(0,c).trim(),body=t.slice(c+1).trim(),js;
   if(m=head.match(/^for\s+(.+?)\s+in\s+(.+)$/)){const tg=m[1].trim(),it=m[2].trim(),mr=it.match(/^range\((.*)\)$/);const src=mr?'__range('+ex(mr[1])+')':'__iter('+ex(it)+')';
    js='for (let '+(tg.includes(',')?'['+tg+']':tg)+' of '+src+') {__g();'}
   else if(m=head.match(/^while\s+(.+)$/))js='while ('+ex(m[1])+') {__g();';
   else if(m=head.match(/^elif\s+(.+)$/))js=pre+'else if ('+ex(m[1])+') {';
   else if(m=head.match(/^if\s+(.+)$/))js='if ('+ex(m[1])+') {';
   else if(head=='else')js=pre+'else {';
   else if(m=head.match(/^def\s+(\w+)\s*\((.*)\)$/))js='function '+m[1]+'('+m[2].replace(/\bTrue\b/g,'true').replace(/\bFalse\b/g,'false').replace(/\bNone\b/g,'null')+') {';
   else if(head=='try')js='try {';
   else if(m=head.match(/^except(?:\s+([\w.]+))?(?:\s+as\s+(\w+))?$/)){const T_=JSON.stringify(m[1]||'Exception'),bind=m[2]?' let '+m[2]+' = __e;':'';
    if(cat[l.ind])js=pre+'else if (__is(__e,'+T_+')) {'+bind;else{cat[l.ind]=1;js=pre+'catch (__e) { if (__is(__e,'+T_+')) {'+bind}
    if(!cat[l.ind]||pre==''&&0){}}
   else if(head=='finally'){js=(cat[l.ind]?pre+END+' ':pre)+'finally {';delete cat[l.ind]}
   else fail(l,'جملة غير مفهومة: '+un(head));
   if(/^(elif|else|except|finally)\b/.test(head)&&!pre&&!/^(else|catch|finally)/.test(js)){}
   if(/^(try)/.test(head)||!cont)js=js;
   if(body){out.push(js);out.push(ex(body)+';');out.push('}')}
   else{out.push(js);stk.push(l.ind)}return}
  if(/^return\b/.test(t)){out.push('return '+ex(t.slice(6))+';');return}
  if(/^(break|continue)$/.test(t)){out.push(t+';');return}
  if(t=='pass'){out.push(';');return}
  if(m=t.match(/^raise\s+\w+\((.*)\)$/)){out.push('throw new Error('+ex(m[1])+');');return}
  if(m=t.match(/^assert\s+(.+?)(?:\s*,\s*(.+))?$/)){out.push('if (!('+ex(m[1])+')) throw new Error("AssertionError"'+(m[2]?'+": "+'+ex(m[2]):'')+');');return}
  out.push(ex(t)+';')});
 let js=out.join('\n');
 return un(js)}
const RT=`var __b='',__n=0,__IN=__INPUTS__;
function __w(s){__b+=s}
function __g(){if(++__n>2000000)throw new Error('LoopError: حلقة لا نهائية؟ توقف التنفيذ بعد تكرارات كثيرة')}
function __r(v){if(v===true)return'True';if(v===false)return'False';if(v==null)return'None';if(typeof v=='string')return"'"+v+"'";if(Array.isArray(v))return'['+v.map(__r).join(', ')+']';if(typeof v=='object')return'{'+Object.entries(v).map(function(e){return __r(e[0])+': '+__r(e[1])}).join(', ')+'}';return String(v)}
function __s(v){return typeof v=='string'?v:v instanceof Error?v.message:__r(v)}
function __f(v,n){return Number(v).toFixed(n)}
function print(){var a=[].slice.call(arguments),sep=' ',end='\\n';a=a.filter(function(x){if(x&&typeof x=='object'&&x.__kw){x.__kw=='sep'?sep=x.v:end=x.v;return false}return true});__w(a.map(__s).join(sep)+end)}
function input(p){__w(p===undefined?'':p);if(!__IN.length)throw new Error('EOFError: لا توجد مدخلات — اكتب القيم (سطر لكل input) في خانة المدخلات');var v=__IN.shift();__w(v+'\\n');return v}
function int(x){if(typeof x=='string'){if(!/^\\s*[-+]?\\d+\\s*$/.test(x))throw new Error("ValueError: invalid literal for int() with base 10: '"+x+"'");return parseInt(x,10)}return Math.trunc(x)}
function float(x){var n=Number(x);if(typeof x=='string'&&(!x.trim()||isNaN(n)))throw new Error("ValueError: could not convert string to float: '"+x+"'");return n}
var str=__s,bool=function(x){return Array.isArray(x)||typeof x=='string'?x.length>0:!!x},abs=Math.abs;
function len(x){return typeof x=='string'||Array.isArray(x)?x.length:Object.keys(x).length}
function __range(a,b,c){var r=[];if(b===undefined){b=a;a=0}c=c||1;if(c>0)for(var i=a;i<b;i+=c)r.push(i);else for(var i=a;i>b;i+=c)r.push(i);return r}
var range=__range;
function __iter(x){return typeof x=='string'||Array.isArray(x)?x:Object.keys(x)}
function __in(x,c){return typeof c=='string'||Array.isArray(c)?c.includes(x):x in c}
function __sl(v,a,b){return typeof v=='string'?v.slice(a,b):v.slice(a,b)}
function __at(v,i){return v[v.length+i]}
function type(x){return "<class '"+(x===null?'NoneType':typeof x=='boolean'?'bool':typeof x=='number'?(Number.isInteger(x)?'int':'float'):typeof x=='string'?'str':Array.isArray(x)?'list':'dict')+"'>"}
function round(x,n){var p=Math.pow(10,n||0);return Math.round(x*p)/p}
function sum(a){return a.reduce(function(x,y){return x+y},0)}
function min(){var a=arguments.length==1?arguments[0]:[].slice.call(arguments);return Math.min.apply(null,a)}
function max(){var a=arguments.length==1?arguments[0]:[].slice.call(arguments);return Math.max.apply(null,a)}
function sorted(a){return a.slice().sort()}
function list(x){return Array.from(__iter(x))}
function set(x){return Array.from(new Set(x))}
function enumerate(a){return Array.from(a).map(function(x,i){return[i,x]})}
var random={randint:function(a,b){return a+Math.floor(Math.random()*(b-a+1))},choice:function(a){return a[Math.floor(Math.random()*a.length)]},random:Math.random},math={sqrt:Math.sqrt,pi:Math.PI,floor:Math.floor,ceil:Math.ceil,pow:Math.pow},time={sleep:function(){}};
var __name__='__main__';
(function(){function d(p,n,f){Object.defineProperty(p,n,{value:f,writable:true,configurable:true,enumerable:false})}
var os=String.prototype.split,or=String.prototype.replace,osort=Array.prototype.sort,opop=Array.prototype.pop;
d(String.prototype,'upper',function(){return this.toUpperCase()});d(String.prototype,'lower',function(){return this.toLowerCase()});d(String.prototype,'strip',function(){return this.trim()});
d(String.prototype,'startswith',function(x){return this.startsWith(x)});d(String.prototype,'endswith',function(x){return this.endsWith(x)});d(String.prototype,'title',function(){return this.replace(/\\b\\w/g,function(c){return c.toUpperCase()})});
d(String.prototype,'join',function(a){return a.map(__s).join(this)});
d(String.prototype,'split',function(s){return s===undefined?this.trim().split(/\\s+/).filter(Boolean):os.call(this,s)});
d(String.prototype,'replace',function(a,b){return typeof a=='string'?os.call(this,a).join(b):or.call(this,a,b)});
d(Array.prototype,'append',function(x){this.push(x)});d(Array.prototype,'extend',function(a){a.forEach(function(x){this.push(x)},this)});
d(Array.prototype,'remove',function(x){var i=this.indexOf(x);if(i<0)throw new Error('ValueError: list.remove(x): x not in list');this.splice(i,1)});
d(Array.prototype,'insert',function(i,x){this.splice(i,0,x)});d(Array.prototype,'index',function(x){return this.indexOf(x)});
d(Array.prototype,'sort',function(f){return osort.call(this,f||function(a,b){return a>b?1:a<b?-1:0})});
d(Array.prototype,'pop',function(i){return i===undefined?opop.call(this):this.splice(i,1)[0]});
})();
function __get(o,k,x){return k in o?o[k]:(x===undefined?null:x)}
function __is(e,t){var m=String(e&&e.message||e);return t=='Exception'||t=='BaseException'||m.indexOf(t)==0||(t=='NameError'&&/is not defined/.test(m))}
function exit(){throw new Error('__exit__')}
var quit=exit;
function __err(e){var m=String(e&&e.message||e),r;if(r=m.match(/^(\\S+) is not defined$/))return'NameError: الاسم «'+r[1]+'» غير معرّف — تأكد من الإملاء وحالة الأحرف (Name ≠ name)';return m}
`;
function buildPy(code,inputs){const js=py2js(code);return RT.replace('__INPUTS__',JSON.stringify(inputs||[]))+'\ntry{(new Function('+JSON.stringify(js)+'))()}catch(e){if(!/__exit__/.test(String(e&&e.message)))__b+="\\n❌ "+__err(e)+"\\n"}\nparent.postMessage({__cm:__b},"*");'}
if(typeof module!='undefined')module.exports={tok,hl,checkCode,py2js,buildPy,RT};
