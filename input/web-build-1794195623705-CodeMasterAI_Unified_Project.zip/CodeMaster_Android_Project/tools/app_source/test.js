const C=require('./core.js'),vm=require('vm');
let pass=0,fail=0;const ok=(n,c,x)=>{c?pass++:(fail++,console.log('FAIL',n,x===undefined?'':JSON.stringify(x)))};
function run(code,inp){let res;try{const s=C.buildPy(code,inp);vm.runInNewContext(s,{parent:{postMessage:m=>res=m.__cm}})}catch(e){return 'COMPILE:'+e.message}return res}
const chk=(c,l)=>C.checkCode(c,l);
// case-sensitivity (the user's key concern)
let e=chk('Print("hi")','py');ok('Print flagged',e.length==1&&/print/.test(e[0].msg)&&e[0].l==5&&e[0].ln==1,e);
ok('print ok',chk('print("hi")','py').length==0);
e=chk('name="a"\nprint(Name)','py');ok('Name vs name',e.length==1&&/name/.test(e[0].msg)&&e[0].ln==2,e);
ok('true flagged',chk('x = true','py').length==1);ok('True ok',chk('x = True\nprint(x)','py').length==0);
ok('Input flagged',chk('x=Input("a")','py').length==1);
ok('Console flagged js',chk('Console.log(1)','js').length==1,chk('Console.log(1)','js'));
ok('console ok js',chk('console.log(1)','js').length==0);
ok('missing colon',chk('if x > 1\n    print(1)','py').some(e=>/:/.test(e.msg)));
ok('unclosed paren',chk('print("a"','py').length>=1);
ok('unclosed str',chk('print("a)','py').some(e=>/نص غير مغلق/.test(e.msg)));
ok('= in if',chk('x=1\nif x = 1:\n    print(x)','py').some(e=>/==/.test(e.msg)));
ok('indent',chk('if True:\nprint(1)','py').some(e=>/مسافة/.test(e.msg)));
ok('html unclosed',chk('<div><span>hi</div>','html').length>=1,chk('<div><span>hi</div>','html'));
ok('html ok',chk('<h1>a</h1><p>x<br><img src="a"></p>','html').length==0);
ok('js syntax',chk('function(){','js').length>=1);
ok('hl bad mark',C.hl('Print("x")','py',[{s:0}]).includes('class=bad'));
// runner
const cases=[
['print("Hello")\nprint(5 + 7)\nprint(9 * 3)',[], 'Hello\n12\n27\n'],
['print(8 + 2)\nprint(8 // 3)\nprint(8 % 3)\nprint(2 ** 3)',[],'10\n2\n2\n8\n'],
['name = "Osama"\nage = 20\nprint(name, age)\nage = 21\nprint(age)',[], 'Osama 20\n21\n'],
['name = input("اسمك: ")\nage = int(input("عمرك: "))\nprint("أهلاً", name)\nprint("بعد خمس سنوات:", age + 5)',['Ali','20'],'اسمك: Ali\nعمرك: 20\nأهلاً Ali\nبعد خمس سنوات: 25\n'],
['score = 70\nif score >= 90:\n    print("ممتاز")\nelif score >= 50:\n    print("ناجح")\nelse:\n    print("حاول")',[],'ناجح\n'],
['age = 22\nhas_id = True\nif age >= 18 and has_id:\n    print("مسموح")',[],'مسموح\n'],
['for number in range(1, 6):\n    print(number)',[],'1\n2\n3\n4\n5\n'],
['count = 1\nwhile count <= 3:\n    print(count)\n    count += 1',[],'1\n2\n3\n'],
['word = "Python"\nprint(word[0])\nprint(word[1:4])\nprint(word.lower())',[],'P\nyth\npython\n'],
['tasks = ["study", "code"]\ntasks.append("test")\ntasks.remove("study")\nprint(tasks)',[],"['code', 'test']\n"],
['point = (10, 20)\nprint(point[0])',[],'10\n'],
['student = {"name": "Mona", "grade": 95}\nprint(student["name"])\nstudent["grade"] = 98\nprint(student)',[],"Mona\n{'name': 'Mona', 'grade': 98}\n"],
['def greet(name):\n    print("أهلاً", name)\ngreet("Ali")',[],'أهلاً Ali\n'],
['def add(a, b):\n    return a + b\nresult = add(4, 6)\nprint(result)',[],'10\n'],
['x = 5\nprint(f"x = {x}")',[],'x = 5\n'],
['print(type("a"), type(1), type(True))',[],"<class 'str'> <class 'int'> <class 'bool'>\n"],
['try:\n    n = int("abc")\nexcept ValueError:\n    print("خطأ")',[],'خطأ\n'],
['print("a", "b", sep="-", end="!")',[],'a-b!'],
['n = int(input("n: "))\nprint(n * 2)',['x'],null],
['print(Name)',[],null],
['i = 0\nwhile True:\n    i += 1',[],null],
['class A:\n    pass',[],'COMPILE:'],
['for i in range(3):\n    if i % 2 == 0:\n        print(i)',[],'0\n2\n'],
['print(17 // 5)\nprint(17 % 5)',[],'3\n2\n'],
['d={"a":1}\nfor k, v in d.items():\n    print(k, v)',[],'a 1\n'],
['t = (1, 2, 3)\nprint(t)',[],'[1, 2, 3]\n'],
['def f(n):\n    if n > 1:\n        return "big"\n    else:\n        return "small"\nprint(f(5), f(0))',[],'big small\n'],
['nums = [3, 1, 2]\nnums.sort()\nprint(nums, len(nums), sum(nums), max(nums))',[],'[1, 2, 3] 3 6 3\n'],
['print("x" in "xyz", 3 not in [1,2])',[],'True True\n'],
['try:\n    n = int("x")\nexcept ZeroDivisionError:\n    print("zero")\nexcept ValueError as e:\n    print("bad", e)\nprint("end")',[],'bad ValueError: invalid literal for int() with base 10: \'x\'\nend\n'],
['try:\n    print(1)\nexcept Exception:\n    print(2)\nfinally:\n    print(3)',[],'1\n3\n'],
['def square(x):\n    return x * x\nassert square(4) == 16\nprint("ok")',[],'ok\n'],
['print(1)\nexit()\nprint(2)',[],'1\n'],
];
cases.forEach(([c,i,exp],k)=>{const r=run(c,i);
 if(exp===null)ok('case'+k+' error shown',/❌/.test(r)&&r.length>5,r);
 else if(exp==='COMPILE:')ok('case'+k+' unsupported msg',/^COMPILE:السطر 1/.test(r),r);
 else ok('case'+k,r===exp,[c,r,exp])});
console.log('err sample:',JSON.stringify(run('n = int(input("n: "))',['x'])), JSON.stringify(run('print(Name)',[])), JSON.stringify(run('i=0\nwhile True:\n    i+=1',[])).slice(0,120));
console.log('pass',pass,'fail',fail);
