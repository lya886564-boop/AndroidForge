const C=require('./core.js'),vm=require('vm'),d=require('./data.json');
let tot=0,fp=0,okRun=0,unsup=0,rterr=0;const bad=[];
const all=[d.l1,...d.units];
all.forEach(u=>u.b.forEach(x=>{if(x[0]!='c'||x[2]!='py')return;tot++;const code=x[1];
 const e=C.checkCode(code,'py');if(e.length){fp++;bad.push(['CHK',u.t,code.slice(0,80),e[0].msg])}
 let r;try{const s=C.buildPy(code,['Ali','20','5','5','5','5','5']);vm.runInNewContext(s,{parent:{postMessage:m=>r=m.__cm}});if(/❌/.test(r)){rterr++;bad.push(['RUN',u.t,code.slice(0,70),r.slice(-90)])}else okRun++}catch(er){unsup++;bad.push(['UNSUP',u.t,code.slice(0,60),er.message.slice(0,80)])}}));
console.log({tot,checkerFlags:fp,ranOk:okRun,unsupported:unsup,runtimeErr:rterr});
bad.forEach(b=>console.log(JSON.stringify(b)));
