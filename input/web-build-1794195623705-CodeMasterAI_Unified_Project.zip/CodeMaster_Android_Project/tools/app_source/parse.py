import re,json
AR=re.compile(r'[\u0600-\u06FF]')
SH=re.compile(r'^(pkg|cd|git|python3?|pip3?|mkdir|nano|source|touch|ls|exit\(\)|pwd|cat|echo|export|termux)\b')
def clean(s):
    s=s.replace('****','').strip()
    return s
def raw(l):
    b=l.strip().startswith('**') and l.strip().endswith('**') and len(l.strip())>4
    t=l.rstrip()
    if b: t=t.strip()[2:-2]
    t=t.replace('****','').replace('\\*','*').replace('\\_','_').replace('\\#','#').replace('\\>','>').replace('\\<','<').replace('\\[','[').replace('\\]',']').replace('\\-','-')
    return b,t
def strip_lit(t):
    t=re.sub(r'"[^"]*"|\'[^\']*\'','""',t)
    return re.sub(r'#.*$','',t)
CODEY=re.compile(r'[=()\[\]{}:]|^\s*(import|from|pkg|cd|git|python|pip|mkdir|nano|source|return|break|continue|pass|else|try|finally)\b')
def classify(b,t):
    s=t.strip()
    if not s: return None
    core=strip_lit(s)
    if AR.search(core): return 'h' if b else 'p'
    if CODEY.search(core) or SH.match(s): return 'c'
    return 'h' if b else 'p'
def unesc_nl(code):
    out=[];q=None;i=0
    while i<len(code):
        ch=code[i]
        if q:
            out.append(ch)
            if ch=='\\' and i+1<len(code): out.append(code[i+1]);i+=1
            elif ch==q: q=None
        else:
            if ch in '"\'': q=ch;out.append(ch)
            elif ch=='\\' and code[i+1:i+2]=='n': out.append('\n');i+=1
            else: out.append(ch)
        i+=1
    return ''.join(out)
def blocks(lines,merge=True):
    B=[];pend=0
    for l in lines:
        b,t=raw(l); k=classify(b,t)
        if k is None:
            pend+=1; continue
        if k=='c':
            t=unesc_nl(t)
            if B and B[-1][0]=='c' and (pend<=1 and merge or pend==0):
                B[-1][1]+='\n'+t
            else: B.append(['c',t])
        elif k=='p' and '\\n' in t and not AR.search(t[:0]):
            B.append(['o',t.replace('\\n','\n')])
        else: B.append([k,t.strip()])
        pend=0
    for x in B:
        if x[0]=='c':
            first=x[1].strip().split('\n')[0]
            x.append('sh' if SH.match(first) and not first.startswith('exit') else 'py')
    return B
def mark_sol(B):
    sol=False
    for x in B:
        if x[0]=='h': sol='الحلول' in x[1]
        elif sol: x.append('sol')
    return B
# ---- lesson 1
L=open('lesson1.md',encoding='utf-8').read().split('\n')
lesson1={'t':'الدرس الأول: تجهيز البيئة وأول برنامج','id':'l1'}
i0=[i for i,l in enumerate(L) if l.startswith('**1)')][0]
secs=[];cur=None
for l in L[i0:]:
    b,t=raw(l)
    if b and re.match(r'^\d+\)',t.strip()):
        cur=[t.strip(),[]];secs.append(cur)
    elif cur is not None: cur[1].append(l)
bl=[];quiz=[]
for title,ls in secs:
    if title.startswith('13)'):
        qs=[re.sub(r'^\d+\.\s*','',x.strip()) for x in ls if re.match(r'^\d+\.',x.strip())]
        ans=[x for x in ls if x.strip().startswith('الإجابات')][0]
        an=[a.strip(' .') for a in re.split(r'\d\)',ans.split(':',1)[1])[1:]]
        quiz=list(zip(qs,an)); continue
    bl.append(['h',title])
    sol='الحلول' in title
    bl+= (mark_sol_b:=blocks(ls,merge=not sol))
    if sol:
        for x in bl[-len(mark_sol_b):]: x.append('sol')
lesson1['b']=bl;lesson1['quiz']=quiz
# ---- full course
F=open('course_full.md',encoding='utf-8').read().split('\n')
units=[];cur=None
for l in F:
    b,t=raw(l)
    m=re.match(r'^الوحدة (\d+): (.+)$',t.strip()) if b else None
    if m: cur={'t':'الوحدة %s: %s'%(m.group(1),m.group(2)),'id':'u'+m.group(1),'ls':[]};units.append(cur)
    elif b and t.strip().startswith('مشاريع تطبيقية'): cur={'t':'مشاريع تطبيقية متدرجة','id':'proj','ls':[]};units.append(cur)
    elif b and t.strip().startswith('خطة مذاكرة'): cur={'t':'خطة مذاكرة – 12 أسبوعاً','id':'plan','ls':[]};units.append(cur)
    elif b and t.strip().startswith('اختبار نهائي'): cur={'t':'الاختبار النهائي الذاتي','id':'exam','ls':[]};units.append(cur)
    elif b and (t.strip().startswith('معايير الوصول') or t.strip().startswith('مراجع رسمية')): cur={'t':t.strip(),'id':'ref'+str(len(units)),'ls':[]};units.append(cur)
    elif cur is not None: cur['ls'].append(l)
intro=[]
exam=[u for u in units if u['id']=='exam'][0]
ql=[re.sub(r'^\d+\.\s*','',x.strip()) for x in exam['ls'] if re.match(r'^\d+\.',x.strip())]
al=[]
for u in units:
    pass
# answers live in a separate bold-titled section "إجابات مختصرة"
ai=[i for i,l in enumerate(F) if 'إجابات مختصرة' in l][0]
al=[raw(x)[1].strip().lstrip('•').strip() for x in F[ai+1:] if x.strip().startswith('•')][:10]
out=[]
for u in units:
    if u['id']=='exam':
        out.append({'id':'exam','t':u['t'],'b':[['p','أجب بنفسك أولًا ثم اكشف الإجابة.']],'quiz':list(zip(ql,al))});continue
    b=blocks(u['ls'])
    if u['id']=='plan':
        b=[x for x in b]
    out.append({'id':u['id'],'t':u['t'],'b':b})
# drop empty answer sections accidentally appended
out=[u for u in out if u['b'] or u.get('quiz')]
json.dump({'l1':lesson1,'units':out},open('data.json','w'),ensure_ascii=False)
print(len(out),'units;',sum(len(u['b']) for u in out),'blocks')
for u in [lesson1]+out[:4]:
    print('==',u['t'])
    for x in u['b'][:14]: print(x[0],repr(x[1])[:90],x[2:] )
