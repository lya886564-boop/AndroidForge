from playwright.sync_api import sync_playwright
import json
errs=[];bad=0
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']);pg=b.new_context(viewport={'width':390,'height':800}).new_page()
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/build/index.html')
    tot=0
    for name,n in [('Flutter',6),('Django',8),('ASP.NET',4)]:
        pg.click('nav button:has-text("الدروس")');pg.click(f'.item:has-text("{name}")')
        ok=pg.locator('.item').count()==n
        print(name,'lessons',pg.locator('.item').count(),'expected',n,'OK' if ok else 'FAIL');bad+=not ok
        for k in range(n):
            pg.click('nav button:has-text("الدروس")');pg.click(f'.item:has-text("{name}")');pg.locator('.item').nth(k).click()
            ok=pg.locator('.code').count()>=1 and pg.locator('.opt').count()==3
            # click options until the correct one is accepted
            for j in range(3):
                pg.locator('.opt').nth(j).click()
                if '✅' in pg.locator('.opt').nth(j).inner_text(): break
            ok=ok and '✅' in pg.locator('#mq').inner_text()
            if not ok: print('FAIL lesson',name,k);bad+=1
            tot+=ok
    xp=json.loads(pg.evaluate('localStorage.cm'))['xp']
    print('lessons completed',tot,'of 18; xp',xp)
    pg.click('nav button:has-text("الدروس")');pg.click('.item:has-text("Flutter")');pg.locator('.item').nth(2).click();pg.screenshot(path='s_fl.png')
    b.close()
print('bad',bad,'errors',errs[:3])
