# Code Master AI — النسخة الموحّدة

ملف تطبيق واحد: `app/src/main/assets/www/index.html` (كل شيء داخله: واجهة + دروس + محرر + مدقّق + مشغّل). لا يحتاج إنترنت ولا مكتبات خارجية.

## ما الذي دُمج؟
- كورس بايثون الكامل (الوحدات 0–13، المشاريع، خطة 12 أسبوعًا، الاختبار النهائي) + الدرس الأول التفصيلي (تمارين وحلول واختبار) من ملفَّي Word.
- هيكل أندرويد (Gradle + WebView) من `CodeMasterAI_Android_Project_FIXED.zip`.
- دورات Flutter وDjango وASP.NET (المستوى الأساسي) كتبتها بصياغة أصلية على هيكل مواضيع Seekho؛ لم تُنسخ نصوصه.
- لم تُدمج حزم React المصغّرة (`index-*.js`) من النسخ القديمة: لا يمكن صيانتها، ولقطتا الشاشة المرفقتان أظهرتا 404/403 عند تحميلها. استُبدلت بتطبيق جديد نظيف.

## بناء APK
1. **GitHub Actions (الأسهل):** ارفع المجلد إلى مستودع GitHub ← تبويب Actions ← Build Android APK ← Run workflow ← نزّل `app-debug.apk`.
2. **Android Studio:** Open المجلد ← Build ← Build APK(s).
3. **سطر الأوامر:** `./gradlew assembleDebug` (يتطلب JDK 17 وAndroid SDK) والناتج في `app/build/outputs/apk/debug/`.
4. **AndroidForge:** ارفع ملف `index.html` وحده إن كنت تفضّل التحويل من الموقع.

## تحديث المحتوى
المصدر في `tools/app_source`:
- عدّل `template.html` (الواجهة والدورات غير بايثون) أو `core.js` (المدقّق والمشغّل).
- لتحديث دروس بايثون: غيّر ملفي Word ثم أعد استخراجهما إلى `lesson1.md` و`course_full.md` وشغّل `python3 parse.py`.
- ثم `python3 build.py` ينتج `index.html` الجديد؛ انسخه إلى `app/src/main/assets/www/` وارفع `versionCode` في `app/build.gradle.kts`.
- الاختبارات: `node test.js` و`node cov.js` و`python3 uitest.py` (يحتاج Playwright).

## النشر على Google Play
حساب مطوّر (25$ مرة واحدة) ← أنشئ مفتاح توقيع (keystore) واحتفظ به ← ابنِ AAB موقّعًا (`./gradlew bundleRelease`) ← أضف سياسة خصوصية ولقطات شاشة ← ارفعه على Play Console. يُنصح بتغيير `applicationId` إن أردت اسمًا خاصًا.

## القيود الحالية (بصراحة)
- Python المحلي مبسّط (متغيرات، شروط، حلقات، دوال، قوائم، قواميس، try/except، assert). لا يدعم class ولا with/open ولا مكتبات خارجية. الناتج العشري قد يختلف (4 بدل 4.0). التشغيل الكامل: Termux.
- SQL وKotlin/Java: تلوين وفحص فقط بدون تشغيل.
- المعلم الذكي محلي بقواعد جاهزة، وليس نموذجًا لغويًا. الإصدار المتصل بالإنترنت غير موجود.
- لا تذكيرات يومية ولا شراء ولا إعلانات (يلزمها كود أندرويد أصلي).
- زر طباعة الشهادة قد لا يعمل داخل WebView؛ استخدم لقطة الشاشة.
