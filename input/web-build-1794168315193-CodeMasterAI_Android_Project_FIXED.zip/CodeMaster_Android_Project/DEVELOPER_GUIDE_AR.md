# توثيق المطور — Code Master AI

راجع صفحة التوثيق داخل التطبيق من زر «توثيق المطور». تفاصيل البناء والتحديث والاختبار وحدود النسخة موضحة في `app/src/main/assets/www/developer-guide.html`.

## بناء APK عبر GitHub Actions
1. ارفع محتويات هذا المجلد إلى جذر مستودع GitHub.
2. افتح Actions وشغّل Build Android APK.
3. بعد نجاح المهمة نزّل Artifact باسم CodeMasterAI-Android-APK.
4. فك الضغط وثبّت `app-debug.apk`.

## بناء محلي
يتطلب JDK 17 وAndroid SDK:
```bash
./gradlew assembleDebug
```
المخرج: `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات مهمة
هذه الحزمة هي غلاف Android WebView لواجهة ويب مضمنة. لا تعني تلقائياً أن كل وظائف الواجهة أو تشغيل Python أو الذكاء الاصطناعي قد تم اختبارها. يجب اختبار الوظائف فعلياً قبل إعلانها مكتملة. لا تضع مفاتيح API في التطبيق أو مستودع عام.
