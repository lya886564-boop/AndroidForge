# 📱 مشروع تطبيق أندرويد الأصلي: Code Master AI
## دليل الفتح والتشغيل في Android Studio خطوة بخطوة

مرحباً بك في الكود المصدري الأصلي لتطبيق **Code Master AI** المصمم لأجهزة الأندرويد بأحدث معايير **Android SDK 34 (Android 14)** ولغة **Kotlin** مع واجهات تفاعلية مدمجة للعمل الكامل دون اتصال بالإنترنت.

---

## 📋 المتطلبات الأساسية
- **نظام التشغيل:** Windows 10/11، macOS (Intel أو Apple Silicon M1/M2/M3)، أو Linux.
- **البرنامج المطلوب:** [Android Studio](https://developer.android.com/studio) (إصدار Hedgehog أو Iguana أو Jellyfish أو أحدث).
- **حزمة الجافا:** JDK 17 (يأتي مدمجاً تلقائياً مع Android Studio).

---

## 🚀 كيفية فتح المشروع وتشغيله في Android Studio (5 خطوات بسيطة)

### الخطوة 1: فك الضغط عن المشروع
- قم بفك ضغط ملف `CodeMaster_Android_Project.zip` في أي مسار تريده على حاسوبك (يفضل مسار بدون مسافات، مثل: `C:\Projects\CodeMaster_Android_Project` أو `~/Projects/CodeMaster_Android_Project`).

### الخطوة 2: فتح المشروع في Android Studio
1. قم بتشغيل برنامج **Android Studio**.
2. من شاشة البداية، اضغط على زر **Open** (أو من القائمة العلوية: **File > Open**).
3. تصفح المجلدات واختر المجلد الذي قمت بفك ضغطه.
4. اضغط **OK**.

### الخطوة 3: مزامنة المشروع (Gradle Sync)
- سيبدأ Android Studio تلقائياً في مزامنة ملفات المشروع وتنزيل الحزم التابعة المعرفة في `build.gradle.kts` عبر أداة `gradlew` المرفقة.
- انتظر بضع لحظات حتى تظهر رسالة في الأسفل: **"BUILD SUCCESSFUL"** أو علامة الصح الخضراء.

### الخطوة 4: تشغيل التطبيق على الهاتف أو المحاكي
1. تأكد من تشغيل محاكي أندرويد (Virtual Device - AVD) أو توصيل هاتف أندرويد حقيقي بحاسوبك عبر كابل USB مع تفعيل **تصحيح أخطاء USB (USB Debugging)**.
2. اضغط على زر التشغيل الأخضر المثلث ▶️ (**Run 'app'**) في الشريط العلوي (أو اختصار `Shift + F10`).
3. سيبدأ التطبيق بالعمل فوراً على شاشة هاتفك مع كامل الميزات ودعم اللغة العربية RTL ووضع الأوفلاين!

---

## 📦 كيفية استخراج ملف APK النهائي الجاهز للتثبيت والمشاركة

### الطريقة الأولى: من خلال قوائم Android Studio
1. من القائمة العلوية، اضغط على **Build**.
2. اختر **Build Bundle(s) / APK(s)** ثم اضغط على **Build APK(s)**.
3. بعد ثوانٍ قليلة، سيظهر إشعار في الزاوية السفلية يفيدك باكتمال البناء:
   > **APK(s) generated successfully for module 'app'**
4. اضغط على كلمة **locate** الزرقاء داخل الإشعار، وسيفتح لك المجلد الذي يحتوي على ملف **`app-debug.apk`**.
5. يمكنك الآن إرسال هذا الملف وتثبيته على أي هاتف أندرويد!

---

### الطريقة الثانية: عبر سطر الأوامر (Terminal)
يمكنك بناء ملف الـ APK بأمر واحد دون فتح الواجهة الرسومية:

```bash
# على أنظمة Linux و macOS:
chmod +x gradlew
./gradlew assembleDebug

# على نظام Windows:
gradlew.bat assembleDebug
```

ستجد ملف الـ APK الناتج في المسار التالي:
`app/build/outputs/apk/debug/app-debug.apk`

---

## ⚡ البناء السحابي التلقائي المجاني عبر GitHub Actions
المشروع مجهز بالكامل بملف سير عمل في المسار:
`.github/workflows/build-apk.yml`

إذا قمت برفع المشروع على حسابك في GitHub:
1. انتقل إلى تبويب **Actions**.
2. اضغط على سير العمل **"Build Android APK"** ثم **"Run workflow"**.
3. ستقوم سحابة GitHub ببناء التطبيق مجاناً في دقيقتين وتوفر لك ملف الـ APK للتنزيل المباشر في قسم **Artifacts**!

---

## 📂 البنية الهيكلية للمشروع
- **`app/src/main/java/com/codemaster/ai/app/MainActivity.kt`**: الشاشة البرمجية الرئيسية بلغة Kotlin مع دعم التخزين المؤقت، وشريط التقدم، وأزرار الرجوع.
- **`app/src/main/AndroidManifest.xml`**: ملف إعدادات التطبيق والأذونات ودعم الاتجاه RTL وشاشات الأندرويد.
- **`app/src/main/assets/www/`**: ملفات تطبيق الويب المتجاوب المضمنة في التطبيق للعمل 100% بدون إنترنت.
- **`app/src/main/res/`**: الأيقونات، الألوان الداكنة (`colors.xml`)، التنسيقات (`themes.xml`)، وتخطيط الواجهة (`activity_main.xml`).
- **`gradle/wrapper/`**: أداة Gradle Wrapper لضمان البناء المستقر والمتوافق على كل الأجهزة.

---

## 🛠️ حل المشاكل الشائعة (Troubleshooting)

- **مشكلة إصدار الجافا (Java Version Mismatch):**
  تأكد من ضبط Gradle JDK على إصدار **Java 17** في Android Studio:
  من **Settings / Preferences > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK** واختر **Embedded JDK 17**.

- **التطبيق يظهر شاشة بيضاء:**
  تأكد من وجود ملفات الويب داخل مجلد `app/src/main/assets/www/index.html`. لقد تم تضمينها مسبقاً وتجهيزها في هذا المشروع.

---
مبروك! مشروعك الأصلي جاهز الآن للانطلاق والتطوير على نظام أندرويد.
